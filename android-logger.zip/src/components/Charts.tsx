import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { tooltipStyle, useChartColors } from './ui'
import { Empty } from './ui'
import { BarChart3 } from 'lucide-react'

const H = 260
function NoData() { return <Empty icon={<BarChart3 size={20} />} title="No data to chart" text="Generate some log events and this chart will populate." /> }

export function HourlyBar({ data }: { data: { hour: string; count: number }[] }) {
  const c = useChartColors()
  if (!data.some(d => d.count)) return <NoData />
  return (
    <ResponsiveContainer width="100%" height={H}>
      <BarChart data={data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
        <CartesianGrid stroke={c.grid} vertical={false} />
        <XAxis dataKey="hour" stroke={c.axis} fontSize={11} tickLine={false} interval={1} />
        <YAxis stroke={c.axis} fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
        <Tooltip {...tooltipStyle(c)} labelFormatter={l => `${l}:00 – ${l}:59`} formatter={(v: number) => [v, 'Events']} />
        <Bar dataKey="count" name="Events" fill={c.series[0]} radius={[4, 4, 0, 0]} maxBarSize={18} />
      </BarChart>
    </ResponsiveContainer>
  )
}

export function AppUsageBar({ data }: { data: { name: string; count: number }[] }) {
  const c = useChartColors()
  if (!data.length) return <NoData />
  const top = data.slice(0, 8)
  return (
    <ResponsiveContainer width="100%" height={H}>
      <BarChart data={top} layout="vertical" margin={{ top: 4, right: 16, left: 8, bottom: 0 }}>
        <CartesianGrid stroke={c.grid} horizontal={false} />
        <XAxis type="number" stroke={c.axis} fontSize={11} tickLine={false} allowDecimals={false} />
        <YAxis type="category" dataKey="name" stroke={c.axis} fontSize={11} tickLine={false} axisLine={false} width={88} />
        <Tooltip {...tooltipStyle(c)} formatter={(v: number) => [v, 'Times opened']} />
        <Bar dataKey="count" name="Times opened" fill={c.series[2]} radius={[0, 4, 4, 0]} maxBarSize={16} />
      </BarChart>
    </ResponsiveContainer>
  )
}

export function TrendLine({ data, xKey, yKey, name, color = 0, area = false }: { data: Record<string, any>[]; xKey: string; yKey: string; name: string; color?: number; area?: boolean }) {
  const c = useChartColors()
  if (!data.some(d => d[yKey])) return <NoData />
  const col = c.series[color]
  const common = { data, margin: { top: 8, right: 12, left: -18, bottom: 0 } }
  const axes = (<>
    <CartesianGrid stroke={c.grid} vertical={false} />
    <XAxis dataKey={xKey} stroke={c.axis} fontSize={11} tickLine={false} minTickGap={24} />
    <YAxis stroke={c.axis} fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
    <Tooltip {...tooltipStyle(c)} cursor={{ stroke: c.axis, strokeDasharray: '3 3' }} />
  </>)
  return (
    <ResponsiveContainer width="100%" height={H}>
      {area ? (
        <AreaChart {...common}>{axes}
          <defs><linearGradient id={`g-${yKey}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={col} stopOpacity={0.35} /><stop offset="100%" stopColor={col} stopOpacity={0} /></linearGradient></defs>
          <Area type="monotone" dataKey={yKey} name={name} stroke={col} strokeWidth={2} fill={`url(#g-${yKey})`} dot={false} activeDot={{ r: 4, stroke: c.tooltipBg, strokeWidth: 2 }} />
        </AreaChart>
      ) : (
        <LineChart {...common}>{axes}
          <Line type="monotone" dataKey={yKey} name={name} stroke={col} strokeWidth={2} dot={{ r: 3, strokeWidth: 0, fill: col }} activeDot={{ r: 5, stroke: c.tooltipBg, strokeWidth: 2 }} />
        </LineChart>
      )}
    </ResponsiveContainer>
  )
}

export function Donut({ data }: { data: { name: string; count: number }[] }) {
  const c = useChartColors()
  if (!data.length) return <NoData />
  const total = data.reduce((a, d) => a + d.count, 0)
  // top 7 + Other (never cycle hues)
  const shown = data.length > 8 ? [...data.slice(0, 7), { name: 'Other', count: data.slice(7).reduce((a, d) => a + d.count, 0) }] : data
  const colorFor = (i: number, name: string) => name === 'Other' ? '#64748b' : c.series[i % 8]
  return (
    <div className="flex flex-col items-center gap-3 sm:flex-row">
      <div className="h-[220px] w-full sm:w-1/2">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={shown} dataKey="count" nameKey="name" innerRadius="58%" outerRadius="90%" paddingAngle={2} stroke={c.tooltipBg} strokeWidth={2}>
              {shown.map((d, i) => <Cell key={d.name} fill={colorFor(i, d.name)} />)}
            </Pie>
            <Tooltip {...tooltipStyle(c)} formatter={(v: number, n: string) => [`${v} (${((v / total) * 100).toFixed(1)}%)`, n]} />
          </PieChart>
        </ResponsiveContainer>
      </div>
      <ul className="w-full space-y-1.5 text-sm sm:w-1/2">
        {shown.map((d, i) => (
          <li key={d.name} className="flex items-center justify-between gap-2">
            <span className="flex items-center gap-2 text-slate-200"><span className="h-2.5 w-2.5 rounded-sm" style={{ background: colorFor(i, d.name) }} />{d.name}</span>
            <span className="tabular-nums text-slate-400">{d.count} · {((d.count / total) * 100).toFixed(0)}%</span>
          </li>
        ))}
      </ul>
    </div>
  )
}

export function SeverityBars({ data }: { data: { name: string; count: number }[] }) {
  const c = useChartColors()
  if (!data.some(d => d.count)) return <NoData />
  const col: Record<string, string> = { DEBUG: '#64748b', INFO: c.series[0], WARN: c.series[3], ERROR: c.series[7], CRITICAL: c.series[4] }
  return (
    <ResponsiveContainer width="100%" height={H}>
      <BarChart data={data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
        <CartesianGrid stroke={c.grid} vertical={false} />
        <XAxis dataKey="name" stroke={c.axis} fontSize={11} tickLine={false} />
        <YAxis stroke={c.axis} fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
        <Tooltip {...tooltipStyle(c)} />
        <Bar dataKey="count" name="Entries" radius={[4, 4, 0, 0]} maxBarSize={36}>
          {data.map(d => <Cell key={d.name} fill={col[d.name]} />)}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  )
}
export { Legend }

import { Activity } from 'lucide-react'
import { useStore } from '../lib/store'
import { fmtTime } from '../lib/format'
import { Empty, SeverityBadge } from './ui'

export default function LiveFeed({ limit = 12, height = 'max-h-[420px]' }: { limit?: number; height?: string }) {
  const { logs, status } = useStore()
  const recent = logs.slice(-limit).reverse()
  if (!recent.length) return <Empty icon={<Activity size={20} />} title="No activity yet" text="Start the logger or press Generate Sample Activity." />
  return (
    <ul className={`${height} space-y-1.5 overflow-y-auto pr-1`} aria-live="polite" aria-label={status === 'running' ? 'Live activity feed' : 'Recent activity'}>
      {recent.map(l => (
        <li key={l.id} className="animate-slideIn rounded-lg border border-white/5 bg-white/5 px-3 py-2">
          <div className="flex items-center justify-between gap-2">
            <span className="font-mono text-[11px] text-slate-400">{fmtTime(l.ts)} · {l.id}</span>
            <SeverityBadge s={l.severity} />
          </div>
          <p className="mt-1 text-sm text-slate-100">{l.description}</p>
          <p className="mt-0.5 truncate text-[11px] text-slate-400">{l.category} · {l.source}</p>
        </li>
      ))}
    </ul>
  )
}

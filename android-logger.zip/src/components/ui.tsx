import { useEffect, type ReactNode } from 'react'
import { AlertTriangle, CheckCircle2, Info, X, XCircle } from 'lucide-react'
import { useStore } from '../lib/store'
import type { Severity, EventStatus } from '../lib/types'

export function Card({ children, className = '', title, action, icon }: { children: ReactNode; className?: string; title?: string; action?: ReactNode; icon?: ReactNode }) {
  return (
    <section className={`glass rounded-2xl p-5 animate-fadeUp ${className}`}>
      {(title || action) && (
        <header className="mb-4 flex items-center justify-between gap-3">
          <h3 className="flex items-center gap-2 text-sm font-semibold tracking-wide text-slate-100">{icon}{title}</h3>
          {action}
        </header>
      )}
      {children}
    </section>
  )
}

export function PageHeader({ title, subtitle, children }: { title: string; subtitle?: string; children?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-white">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-slate-400">{subtitle}</p>}
      </div>
      <div className="flex flex-wrap items-center gap-2">{children}</div>
    </div>
  )
}

export function StatCard({ label, value, hint, icon, tone = 'default' }: { label: string; value: ReactNode; hint?: ReactNode; icon: ReactNode; tone?: 'default' | 'good' | 'warn' | 'bad' }) {
  const tones = { default: 'text-sky-300 bg-sky-400/10', good: 'text-emerald-300 bg-emerald-400/10', warn: 'text-amber-300 bg-amber-400/10', bad: 'text-red-300 bg-red-400/10' }
  return (
    <div className="glass rounded-2xl p-4 animate-fadeUp">
      <div className="flex items-start justify-between">
        <span className="label">{label}</span>
        <span className={`rounded-lg p-1.5 ${tones[tone]}`}>{icon}</span>
      </div>
      <div className="mt-2 text-2xl font-semibold tabular-nums text-white">{value}</div>
      {hint && <div className="mt-1 text-xs text-slate-400">{hint}</div>}
    </div>
  )
}

const sevStyle: Record<Severity, string> = {
  DEBUG: 'bg-slate-500/15 text-slate-300 border-slate-400/20',
  INFO: 'bg-sky-500/15 text-sky-300 border-sky-400/20',
  WARN: 'bg-amber-500/15 text-amber-300 border-amber-400/25',
  ERROR: 'bg-red-500/15 text-red-300 border-red-400/25',
  CRITICAL: 'bg-fuchsia-500/20 text-fuchsia-300 border-fuchsia-400/30',
}
export function SeverityBadge({ s }: { s: Severity }) {
  return <span className={`inline-block rounded-md border px-1.5 py-0.5 text-[11px] font-semibold ${sevStyle[s]}`}>{s}</span>
}
export function StatusBadge({ s }: { s: EventStatus }) {
  const c = s === 'Success' ? 'text-emerald-300' : s === 'Failed' ? 'text-red-300' : 'text-amber-300'
  const Icon = s === 'Success' ? CheckCircle2 : s === 'Failed' ? XCircle : Info
  return <span className={`inline-flex items-center gap-1 text-xs ${c}`}><Icon size={13} />{s}</span>
}

export function Pill({ tone, children, pulse }: { tone: 'good' | 'warn' | 'bad' | 'idle' | 'info'; children: ReactNode; pulse?: boolean }) {
  const t = {
    good: 'bg-emerald-500/10 text-emerald-300 border-emerald-400/25', warn: 'bg-amber-500/10 text-amber-300 border-amber-400/25',
    bad: 'bg-red-500/10 text-red-300 border-red-400/25', idle: 'bg-slate-500/10 text-slate-300 border-slate-400/20', info: 'bg-sky-500/10 text-sky-300 border-sky-400/25',
  }[tone]
  const dot = { good: 'bg-emerald-400', warn: 'bg-amber-400', bad: 'bg-red-400', idle: 'bg-slate-400', info: 'bg-sky-400' }[tone]
  return (
    <span className={`inline-flex items-center gap-2 rounded-full border px-2.5 py-1 text-xs font-medium ${t}`}>
      <span className="relative flex h-2 w-2">
        {pulse && <span className={`absolute inline-flex h-full w-full animate-ping rounded-full opacity-70 ${dot}`} />}
        <span className={`relative inline-flex h-2 w-2 rounded-full ${dot}`} />
      </span>
      {children}
    </span>
  )
}

export function Empty({ icon, title, text }: { icon: ReactNode; title: string; text?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 py-10 text-center text-slate-400">
      <div className="rounded-full bg-white/5 p-3">{icon}</div>
      <p className="text-sm font-medium text-slate-200">{title}</p>
      {text && <p className="max-w-sm text-xs">{text}</p>}
    </div>
  )
}

export function Toggle({ checked, onChange, label, hint }: { checked: boolean; onChange: (v: boolean) => void; label: string; hint?: string }) {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-4 py-2">
      <span>
        <span className="block text-sm text-slate-100">{label}</span>
        {hint && <span className="block text-xs text-slate-400">{hint}</span>}
      </span>
      <button type="button" role="switch" aria-checked={checked} onClick={() => onChange(!checked)}
        className={`relative h-6 w-11 shrink-0 rounded-full transition ${checked ? 'bg-brand-500' : 'bg-slate-600/60'}`}>
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${checked ? 'left-[22px]' : 'left-0.5'}`} />
      </button>
    </label>
  )
}

export function Toasts() {
  const { toasts, dismissToast } = useStore()
  const icon = { success: <CheckCircle2 className="text-emerald-400" size={18} />, error: <XCircle className="text-red-400" size={18} />, info: <Info className="text-sky-400" size={18} />, warning: <AlertTriangle className="text-amber-400" size={18} /> }
  return (
    <div className="pointer-events-none fixed bottom-4 right-4 z-[60] flex w-[min(92vw,360px)] flex-col gap-2">
      {toasts.map(t => (
        <div key={t.id} className="glass pointer-events-auto animate-slideIn rounded-xl p-3 !bg-slate-900/90">
          <div className="flex items-start gap-3">
            {icon[t.type]}
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-white">{t.title}</p>
              {t.message && <p className="mt-0.5 break-words text-xs text-slate-300">{t.message}</p>}
            </div>
            <button onClick={() => dismissToast(t.id)} className="text-slate-400 hover:text-white" aria-label="Dismiss"><X size={14} /></button>
          </div>
        </div>
      ))}
    </div>
  )
}

export function ConfirmDialog() {
  const { confirmState } = useStore()
  useEffect(() => {
    if (!confirmState) return
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') confirmState.resolve(false) }
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h)
  }, [confirmState])
  if (!confirmState) return null
  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm" onClick={() => confirmState.resolve(false)}>
      <div className="glass w-full max-w-md animate-fadeUp rounded-2xl p-6 !bg-slate-900/95" onClick={e => e.stopPropagation()} role="dialog" aria-modal="true">
        <h3 className="text-lg font-semibold text-white">{confirmState.title}</h3>
        <p className="mt-2 text-sm text-slate-300">{confirmState.message}</p>
        <div className="mt-6 flex justify-end gap-2">
          <button className="btn-ghost" onClick={() => confirmState.resolve(false)}>Cancel</button>
          <button className={confirmState.danger ? 'btn-danger' : 'btn-primary'} onClick={() => confirmState.resolve(true)} autoFocus>{confirmState.confirmLabel ?? 'Confirm'}</button>
        </div>
      </div>
    </div>
  )
}

/** chart palette (validated categorical dark-mode steps; light-mode steps for light theme) */
export function useChartColors() {
  const { settings } = useStore()
  const dark = settings.theme === 'dark'
  return {
    series: dark
      ? ['#3987e5', '#d95926', '#199e70', '#c98500', '#d55181', '#0ca30c', '#9085e9', '#e66767']
      : ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300', '#6250d6', '#e34948'],
    grid: dark ? 'rgba(148,163,184,.14)' : 'rgba(15,23,42,.12)',
    axis: dark ? '#94a3b8' : '#475569',
    tooltipBg: dark ? '#0f172a' : '#ffffff',
    tooltipBorder: dark ? 'rgba(148,163,184,.25)' : 'rgba(15,23,42,.15)',
    text: dark ? '#e2e8f0' : '#0f172a',
  }
}
export function tooltipStyle(c: ReturnType<typeof useChartColors>) {
  return { contentStyle: { background: c.tooltipBg, border: `1px solid ${c.tooltipBorder}`, borderRadius: 10, fontSize: 12, color: c.text }, labelStyle: { color: c.text }, itemStyle: { color: c.text }, cursor: { fill: 'rgba(148,163,184,.08)' } }
}

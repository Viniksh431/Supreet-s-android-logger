import { useState } from 'react'
import { Copy, KeyRound, RotateCcw, Save } from 'lucide-react'
import { useStore } from '../lib/store'
import { Card, PageHeader, Pill, Toggle } from '../components/ui'
import { fmtBytes } from '../lib/format'
import { redirectUri } from '../lib/dropbox'

export default function SettingsPage() {
  const { settings: s, updateSettings, resetSettings, notify, storageUsed, logs, confirm } = useStore()
  const [key, setKey] = useState(s.dropboxAppKey)
  const Field = ({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) => (
    <div className="py-2"><label className="label mb-1.5 block">{label}</label>{children}{hint && <p className="mt-1 text-xs text-slate-400">{hint}</p>}</div>
  )
  return (
    <>
      <PageHeader title="Settings" subtitle="All settings are saved automatically and persist across browser refreshes.">
        <button className="btn-ghost" onClick={async () => { if (await confirm({ title: 'Reset settings?', message: 'All settings return to their defaults. Logs are not affected.', confirmLabel: 'Reset' })) { resetSettings(); setKey(''); notify({ type: 'info', title: 'Settings reset to defaults' }) } }}><RotateCcw size={15} />Reset to defaults</button>
      </PageHeader>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Logger">
          <Field label={`Logger refresh interval: ${s.refreshIntervalSec}s`} hint="How often the simulator emits new events while running.">
            <input type="range" min={1} max={30} value={s.refreshIntervalSec} onChange={e => updateSettings({ refreshIntervalSec: +e.target.value })} className="w-full accent-green-500" />
          </Field>
          <Toggle label="Automatic logging" hint="Start the logger automatically when the app loads." checked={s.autoLogging} onChange={v => updateSettings({ autoLogging: v })} />
          <Field label="Log retention" hint="Entries older than this are pruned automatically.">
            <select className="input" value={s.retentionDays} onChange={e => updateSettings({ retentionDays: +e.target.value })}>
              <option value={1}>1 day</option><option value={3}>3 days</option><option value={7}>7 days</option><option value={30}>30 days</option><option value={0}>Keep forever</option>
            </select>
          </Field>
          <Field label="Maximum stored entries" hint="Oldest entries are dropped beyond this limit (browser storage is limited).">
            <select className="input" value={s.maxEntries} onChange={e => updateSettings({ maxEntries: +e.target.value })}>
              {[1000, 2500, 5000, 10000].map(n => <option key={n} value={n}>{n.toLocaleString()}</option>)}
            </select>
          </Field>
        </Card>
        <Card title="Export & appearance">
          <Field label="Default export format" hint="Used by “Download complete log” and the Dropbox “Upload Logs” button.">
            <div className="flex gap-2">{(['txt', 'csv'] as const).map(f => <button key={f} onClick={() => updateSettings({ exportFormat: f })} className={s.exportFormat === f ? 'btn-primary' : 'btn-ghost'}>{f.toUpperCase()}</button>)}</div>
          </Field>
          <Field label="Theme">
            <div className="flex gap-2">{(['dark', 'light'] as const).map(t => <button key={t} onClick={() => updateSettings({ theme: t })} className={`capitalize ${s.theme === t ? 'btn-primary' : 'btn-ghost'}`}>{t}</button>)}</div>
          </Field>
          <div className="mt-3 rounded-xl border border-white/10 bg-black/20 p-3 text-xs text-slate-400">
            Browser storage used by Android Logger: <b className="text-slate-200">{fmtBytes(storageUsed)}</b> · {logs.length.toLocaleString()} entries stored
          </div>
        </Card>
        <Card title="Synchronization">
          <Toggle label="Demo Mode" hint="Simulate Dropbox sync locally. Clearly labelled; never reports a real upload." checked={s.demoMode} onChange={v => updateSettings({ demoMode: v })} />
          <Toggle label="Inject random failures (Demo Mode)" hint="Occasionally fail simulated uploads to exercise error handling." checked={s.demoFailures} onChange={v => updateSettings({ demoFailures: v })} />
          <Toggle label="Automatic sync" hint="Periodically run a full sync while the app is open and connected." checked={s.autoSync} onChange={v => updateSettings({ autoSync: v })} />
          <Field label="Auto-sync interval">
            <select className="input" value={s.autoSyncMinutes} onChange={e => updateSettings({ autoSyncMinutes: +e.target.value })} disabled={!s.autoSync}>
              {[1, 5, 15, 30, 60].map(n => <option key={n} value={n}>Every {n} min</option>)}
            </select>
          </Field>
        </Card>
        <Card title="Dropbox configuration" icon={<KeyRound size={16} />} action={s.dropboxAppKey ? <Pill tone="good">App key set</Pill> : <Pill tone="warn">Not configured</Pill>}>
          <Field label="Dropbox App key" hint="From your app at dropbox.com/developers/apps. PKCE is used, so no App secret is needed or stored.">
            <div className="flex gap-2">
              <input className="input font-mono" value={key} onChange={e => setKey(e.target.value)} placeholder="e.g. abc123xyz456" spellCheck={false} />
              <button className="btn-primary" onClick={() => { updateSettings({ dropboxAppKey: key.trim() }); notify({ type: 'success', title: 'Dropbox App key saved' }) }}><Save size={15} />Save</button>
            </div>
          </Field>
          <div className="mt-2 space-y-1 text-xs text-slate-400">
            <p>Redirect URI to register in the Dropbox console:</p>
            <div className="flex items-center gap-2"><code className="flex-1 break-all rounded bg-black/30 px-2 py-1.5 font-mono text-slate-200">{redirectUri()}</code>
              <button className="btn-ghost !p-2" aria-label="Copy" onClick={() => { navigator.clipboard?.writeText(redirectUri()); notify({ type: 'info', title: 'Copied' }) }}><Copy size={14} /></button></div>
            <p>Required permissions: <span className="font-mono">account_info.read, files.content.write, files.content.read</span></p>
            <p>Status: {s.dropboxAppKey ? 'App key present – turn Demo Mode off and use Connect on the Dropbox page.' : 'No App key. Demo Mode will be used.'}</p>
          </div>
        </Card>
      </div>
    </>
  )
}

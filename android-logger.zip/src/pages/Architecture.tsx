import { ArrowDown, Cloud, Cpu, Database, LineChart, ScrollText, Share2, Smartphone, Zap } from 'lucide-react'
import { Card, PageHeader } from '../components/ui'

const STAGES = [
  { icon: Smartphone, name: 'Android Activity Simulator', file: 'lib/generator.ts · DeviceState', color: 'text-sky-300 bg-sky-400/10', text: 'Maintains a simulated device (screen, keyguard, Wi-Fi, Bluetooth, battery, foreground app). It represents the Android OS and the user whose actions create events. In a real phone this role is played by the kernel, system services and the user.' },
  { icon: Zap, name: 'Activity Event Generator', file: 'lib/generator.ts · nextEvents()', color: 'text-amber-300 bg-amber-400/10', text: 'A state machine that chooses the next plausible event from the current device state (e.g. an app can only close if it was opened; unlock needs the screen on). Mirrors Android broadcast intents such as ACTION_SCREEN_ON or CONNECTIVITY_CHANGE.' },
  { icon: ScrollText, name: 'Logging Engine', file: 'lib/store.tsx · timer + appendRaw()', color: 'text-emerald-300 bg-emerald-400/10', text: 'A timer-driven background “service” that runs Start / Pause / Resume / Stop, assigns unique IDs and timestamps, tags category, severity and status, and applies retention. Comparable to an Android foreground Service writing to logcat.' },
  { icon: Database, name: 'Local Log Storage', file: 'localStorage (androidlogger.*)', color: 'text-violet-300 bg-violet-400/10', text: 'Persists logs, settings and sync history in the browser so everything survives a refresh. On Android this would be a file under app-private storage or a Room/SQLite database.' },
  { icon: LineChart, name: 'Log Processing & Analytics', file: 'lib/analytics.ts · computeAnalytics()', color: 'text-pink-300 bg-pink-400/10', text: 'Aggregates the raw entries into hourly and daily distributions, app-usage frequency, rates, storage size and sync statistics. All dashboards and the daily report JSON are derived from it.' },
  { icon: Share2, name: 'Dropbox API Integration', file: 'lib/dropbox.ts · store.runSync()', color: 'text-sky-300 bg-sky-400/10', text: 'OAuth 2.0 Authorization Code flow with PKCE, token refresh, /users/get_current_account and /files/upload. In Demo Mode the same pipeline runs but the network step is simulated and labelled as such.' },
  { icon: Cloud, name: 'Cloud Storage', file: '/AndroidLogger/Logs · /Reports', color: 'text-cyan-300 bg-cyan-400/10', text: 'Dropbox holds the exported TXT/CSV log files and daily_report.json, giving off-device backup and access from any machine.' },
]

export default function Architecture() {
  return (
    <>
      <PageHeader title="System Architecture" subtitle="End-to-end data flow from simulated Android activity to cloud storage." />
      <Card title="Data flow diagram">
        <div className="mx-auto flex max-w-xl flex-col items-center">
          {STAGES.map((s, i) => (
            <div key={s.name} className="flex w-full flex-col items-center">
              <div className="flex w-full items-center gap-4 rounded-2xl border border-white/10 bg-white/5 px-5 py-3.5 transition hover:border-brand-500/40 hover:bg-white/10">
                <span className={`rounded-xl p-2.5 ${s.color}`}><s.icon size={20} /></span>
                <div className="min-w-0"><p className="text-sm font-semibold text-white">{i + 1}. {s.name}</p><p className="truncate font-mono text-[11px] text-slate-400">{s.file}</p></div>
              </div>
              {i < STAGES.length - 1 && <div className="flex h-8 flex-col items-center justify-center text-brand-400"><div className="h-3 w-px bg-brand-500/50" /><ArrowDown size={16} /></div>}
            </div>
          ))}
        </div>
      </Card>

      <div className="mt-4 grid gap-4 md:grid-cols-2">
        {STAGES.map((s, i) => (
          <Card key={s.name} title={`${i + 1}. ${s.name}`} icon={<s.icon size={16} className={s.color.split(' ')[0]} />}>
            <p className="text-sm leading-relaxed text-slate-300">{s.text}</p>
          </Card>
        ))}
        <Card title="Event-driven design" icon={<Cpu size={16} />}>
          <p className="text-sm leading-relaxed text-slate-300">The UI never polls for data. Each generated event is pushed into React state, which re-renders the feed, tables and charts that depend on it. Analytics are derived values, so a new event updates every statistic automatically — the same producer/consumer idea used by Android’s broadcast system.</p>
        </Card>
      </div>
      <Card title="Developer details" className="mt-4">
        <dl className="grid gap-3 text-sm sm:grid-cols-3">
          <div><dt className="label">Name</dt><dd className="mt-1 text-slate-100">Supreet Kothuri</dd></div>
          <div><dt className="label">Registration No.</dt><dd className="mt-1 font-mono text-slate-100">AP24110011933</dd></div>
          <div><dt className="label">Section</dt><dd className="mt-1 text-slate-100">SEC - R</dd></div>
        </dl>
      </Card>
    </>
  )
}

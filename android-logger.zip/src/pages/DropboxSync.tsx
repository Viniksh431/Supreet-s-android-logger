import { AlertTriangle, CheckCircle2, Cloud, CloudUpload, FileText, Folder, FolderOpen, History, LogOut, RefreshCw, ShieldCheck, Upload, XCircle } from 'lucide-react'
import { useStore } from '../lib/store'
import { fmtBytes, fmtDateTime, relTime } from '../lib/format'
import { Card, Empty, PageHeader, Pill, StatCard } from '../components/ui'
import { redirectUri } from '../lib/dropbox'

export default function DropboxSync() {
  const s = useStore()
  const { settings, connected, account, progress, syncs, remoteFiles, analytics: a, now } = s
  const demo = settings.demoMode
  const mode = demo ? 'demo' : 'live'
  const stats = a.sync[mode]
  const lastOk = syncs.find(x => x.mode === mode && x.status !== 'failed')
  const busy = !!progress
  const files = remoteFiles.filter(f => f.mode === mode).sort((x, y) => x.path.localeCompare(y.path))
  const folders = ['/AndroidLogger/Logs', '/AndroidLogger/Reports']

  return (
    <>
      <PageHeader title="Dropbox Sync" subtitle="Synchronize log files with Dropbox cloud storage using OAuth 2.0 (PKCE) and the Dropbox HTTP API.">
        {demo ? <Pill tone="warn">DEMO MODE – simulated, no real uploads</Pill> : <Pill tone="info">LIVE MODE – real Dropbox API</Pill>}
      </PageHeader>

      {demo && (
        <div className="mb-4 flex items-start gap-3 rounded-xl border border-amber-400/30 bg-amber-400/10 p-4 text-sm text-amber-100">
          <AlertTriangle size={18} className="mt-0.5 shrink-0" />
          <p><b>Demo Mode is active.</b> Synchronization is simulated entirely in your browser. Nothing is sent to Dropbox, and every demo record is labelled “simulated”. To upload to your own Dropbox, turn off Demo Mode in Settings and add your Dropbox App key.</p>
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Connection" icon={<Cloud size={16} />} className="lg:col-span-1"
          action={connected ? <Pill tone={demo ? 'warn' : 'good'}>{demo ? 'Demo (simulated)' : 'Connected'}</Pill> : <Pill tone="idle">Disconnected</Pill>}>
          {connected && account ? (
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-3">
                <div className="grid h-11 w-11 place-items-center rounded-full bg-sky-500/20 text-lg font-semibold text-sky-200">{account.name.charAt(0).toUpperCase()}</div>
                <div className="min-w-0"><p className="truncate font-medium text-white">{account.name}</p><p className="truncate text-xs text-slate-400">{account.email}</p></div>
              </div>
              <div className="flex justify-between text-xs"><span className="text-slate-400">Account type</span><span className="text-slate-200">{demo ? 'Simulated' : account.accountType}</span></div>
              <div className="flex justify-between text-xs"><span className="text-slate-400">Account ID</span><span className="truncate pl-4 font-mono text-slate-200">{account.accountId}</span></div>
              <div className="flex justify-between text-xs"><span className="text-slate-400">Authorization</span><span className="text-slate-200">{demo ? 'None (demo)' : 'OAuth 2.0 + PKCE'}</span></div>
              <button className="btn-danger mt-3 w-full" onClick={s.disconnectDropbox} disabled={busy}><LogOut size={15} />Disconnect Dropbox</button>
            </div>
          ) : (
            <div className="space-y-3 text-sm text-slate-300">
              <p>{demo ? 'Connect a simulated Dropbox account to try the full sync workflow without any credentials.' : 'You will be sent to dropbox.com to explicitly authorize Android Logger. Tokens are stored only in this browser.'}</p>
              {!demo && !settings.dropboxAppKey && <p className="rounded-lg bg-red-500/10 p-2 text-xs text-red-200">No Dropbox App key configured. Add one in Settings → Dropbox Configuration.</p>}
              <button className="btn-primary w-full" onClick={s.connectDropbox}><Cloud size={15} />Connect to Dropbox{demo ? ' (Demo)' : ''}</button>
            </div>
          )}
          {!demo && <p className="mt-3 break-all text-[11px] text-slate-500">Redirect URI to register: <span className="font-mono">{redirectUri()}</span></p>}
        </Card>

        <div className="grid grid-cols-2 gap-4 lg:col-span-2">
          <StatCard label="Last synchronization" value={<span className="text-lg">{relTime(lastOk?.ts ?? null, now)}</span>} hint={lastOk ? `${fmtDateTime(lastOk.ts)}${demo ? ' · simulated' : ''}` : 'No successful sync yet'} icon={<History size={16} />} />
          <StatCard label={`Files synchronized${demo ? ' (simulated)' : ''}`} value={stats.files} hint={`${stats.success} ok · ${stats.failed} failed`} icon={<FileText size={16} />} tone="good" />
          <StatCard label={`Data uploaded${demo ? ' (simulated)' : ''}`} value={fmtBytes(stats.bytes)} hint={`${stats.total} sync run(s)`} icon={<CloudUpload size={16} />} />
          <StatCard label="Pending log size" value={fmtBytes(a.logBytes)} hint={`${a.total} entries ready`} icon={<Upload size={16} />} tone="warn" />
        </div>
      </div>

      <Card title="Synchronize" className="mt-4" icon={<RefreshCw size={16} />}>
        <div className="flex flex-wrap gap-2">
          <button className="btn-ghost" onClick={() => s.runSync('upload')} disabled={busy || !connected}><Upload size={15} />Upload Logs ({settings.exportFormat.toUpperCase()})</button>
          <button className="btn-primary" onClick={() => s.runSync('sync')} disabled={busy || !connected}><RefreshCw size={15} className={busy ? 'animate-spin' : ''} />Sync Now (logs + report)</button>
          {!connected && <span className="self-center text-xs text-slate-400">Connect to Dropbox to enable sync.</span>}
        </div>
        <p className="mt-2 text-xs text-slate-400">Upload Logs sends one log file in your selected export format. Sync Now sends TXT + CSV logs and <span className="font-mono">daily_report.json</span>. {settings.autoSync ? `Auto-sync runs every ${settings.autoSyncMinutes} min.` : 'Auto-sync is off (Settings).'}</p>

        {progress && (
          <div className="mt-4 rounded-xl border border-white/10 bg-black/30 p-4" role="status" aria-live="polite">
            <div className="mb-2 flex items-center justify-between text-xs">
              <span className="font-medium capitalize text-slate-200">{progress.mode === 'demo' ? '[DEMO – simulated] ' : '[LIVE] '}{progress.phase}</span>
              <span className="tabular-nums text-slate-300">{Math.round(progress.pct)}%</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-brand-500 transition-all duration-300" style={{ width: `${progress.pct}%` }} /></div>
            <p className="mt-2 truncate font-mono text-xs text-slate-400">{progress.message}</p>
          </div>
        )}
      </Card>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card title={demo ? 'Simulated Dropbox folder' : 'Dropbox folder (uploaded by this app)'} icon={<FolderOpen size={16} />}>
          <p className="mb-3 font-mono text-xs text-slate-400">/AndroidLogger/</p>
          {files.length === 0 ? <Empty icon={<Folder size={20} />} title="Folder is empty" text="Run a sync and uploaded files will appear here." /> : (
            <ul className="space-y-3 text-sm">
              {folders.map(dir => {
                const inDir = files.filter(f => f.path.startsWith(dir + '/'))
                return (
                  <li key={dir}>
                    <p className="flex items-center gap-2 font-medium text-slate-200"><Folder size={15} className="text-sky-300" />{dir.split('/').pop()}/</p>
                    <ul className="ml-6 mt-1 space-y-1">
                      {inDir.length === 0 && <li className="text-xs text-slate-500">(empty)</li>}
                      {inDir.map(f => (
                        <li key={f.path} className="flex items-center justify-between gap-2 text-xs">
                          <span className="flex min-w-0 items-center gap-2 text-slate-300"><FileText size={13} /><span className="truncate font-mono">{f.path.split('/').pop()}</span></span>
                          <span className="shrink-0 text-slate-500">{fmtBytes(f.size)} · {relTime(f.ts, now)}</span>
                        </li>
                      ))}
                    </ul>
                  </li>
                )
              })}
            </ul>
          )}
          {demo && files.length > 0 && <p className="mt-3 text-[11px] text-amber-300/80">Simulated listing – these files exist only in this browser.</p>}
        </Card>

        <Card title="Sync history" icon={<History size={16} />} action={syncs.length ? <button className="text-xs text-slate-400 hover:text-white" onClick={s.clearSyncHistory}>Clear</button> : undefined}>
          {syncs.length === 0 ? <Empty icon={<History size={20} />} title="No sync history" text="Completed and failed syncs are recorded here." /> : (
            <ul className="max-h-[420px] space-y-2 overflow-y-auto pr-1">
              {syncs.map(r => (
                <li key={r.id} className="rounded-lg border border-white/5 bg-white/5 p-3 text-xs">
                  <div className="flex items-center justify-between gap-2">
                    <span className="flex items-center gap-1.5 font-medium text-slate-100">
                      {r.status === 'success' ? <CheckCircle2 size={14} className="text-emerald-400" /> : r.status === 'partial' ? <AlertTriangle size={14} className="text-amber-400" /> : <XCircle size={14} className="text-red-400" />}
                      {r.id} · {r.kind === 'sync' ? 'Full sync' : 'Log upload'}
                    </span>
                    <span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${r.mode === 'demo' ? 'bg-amber-400/15 text-amber-300' : 'bg-sky-400/15 text-sky-300'}`}>{r.mode === 'demo' ? 'DEMO · SIMULATED' : 'LIVE'}</span>
                  </div>
                  <p className="mt-1 text-slate-400">{fmtDateTime(r.ts)} · {r.trigger} · {r.files.filter(f => f.ok).length}/{r.files.length} files · {fmtBytes(r.bytes)} · {(r.durationMs / 1000).toFixed(1)}s</p>
                  {r.error && <p className="mt-1 break-words text-red-300">{r.error}</p>}
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
      <p className="mt-4 flex items-center gap-2 text-xs text-slate-500"><ShieldCheck size={14} />Only log files you generate here are uploaded, and only after you connect and trigger a sync (or enable auto-sync).</p>
    </>
  )
}

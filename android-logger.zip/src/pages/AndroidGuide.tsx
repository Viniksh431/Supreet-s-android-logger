import { AlertTriangle, CheckCircle2, ShieldCheck } from 'lucide-react'
import { Card, PageHeader } from '../components/ui'

const OS = [
  ['Event monitoring', 'Generator emits system-style events; each is observed, recorded and displayed in real time.'],
  ['Process & application activity', 'Application opened / closed events model the app lifecycle (foreground, background, ANR).'],
  ['System event logging', 'Unique IDs, timestamps, categories and severity levels, similar to Android logcat levels.'],
  ['Data storage & management', 'Persistent local store with search, filtering, retention limits and export.'],
  ['Background task simulation', 'Start / Pause / Resume / Stop mimic a background Service with a lifecycle.'],
  ['Event-driven architecture', 'State changes push through the UI; analytics recompute from the event stream.'],
  ['Cloud storage integration', 'Log files and a JSON report are synchronised to Dropbox folders.'],
  ['Network communication', 'HTTPS REST calls to the Dropbox API; Wi-Fi/network events are logged too.'],
  ['Data synchronization', 'Snapshot → upload → verify → record history, with success/failure tracking and auto-sync.'],
]
const APIS = [
  ['Application opened / closed', 'UsageStatsManager (queryEvents) with the PACKAGE_USAGE_STATS special-access permission, or an AccessibilityService only if explicitly user-enabled.'],
  ['Screen ON / OFF, unlock / lock', 'Dynamic BroadcastReceiver for ACTION_SCREEN_ON, ACTION_SCREEN_OFF and ACTION_USER_PRESENT.'],
  ['Wi-Fi & network changes', 'ConnectivityManager.registerDefaultNetworkCallback (ACCESS_NETWORK_STATE); WifiManager needs location-related permissions on newer Android versions.'],
  ['Bluetooth state', 'BluetoothAdapter state broadcasts (ACTION_STATE_CHANGED); BLUETOOTH_CONNECT permission on Android 12+.'],
  ['Battery & charging', 'ACTION_BATTERY_CHANGED, ACTION_POWER_CONNECTED / DISCONNECTED, BatteryManager.'],
  ['Boot / restart', 'BroadcastReceiver for ACTION_BOOT_COMPLETED (RECEIVE_BOOT_COMPLETED permission).'],
  ['Always-on logging', 'A foreground Service with a persistent notification; WorkManager for periodic, battery-aware uploads.'],
  ['Storage', 'App-private files or Room/SQLite database; no broad storage permission required.'],
  ['Dropbox upload', 'Official Dropbox Android/Java SDK or HTTP API with OAuth 2.0 PKCE via a Custom Tab.'],
]

export default function AndroidGuide() {
  return (
    <>
      <PageHeader title="Android Guide & OS Concepts" subtitle="How this simulator maps to operating-system concepts and to a real Android implementation." />
      <div className="mb-4 rounded-xl border border-amber-400/30 bg-amber-400/10 p-4 text-sm text-amber-100">
        <p className="flex items-center gap-2 font-semibold"><AlertTriangle size={17} />Browser simulator ≠ real Android monitoring</p>
        <p className="mt-1">This web app runs in a browser sandbox and has no access to any phone. All events are produced by a software model. A real Android logger must be a native app, installed on the device and granted permissions by the user, and Android deliberately restricts what apps can observe.</p>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="OS concepts demonstrated">
          <ul className="space-y-3">{OS.map(([k, v]) => <li key={k} className="flex gap-3 text-sm"><CheckCircle2 size={16} className="mt-0.5 shrink-0 text-brand-400" /><span><b className="text-slate-100">{k}.</b> <span className="text-slate-300">{v}</span></span></li>)}</ul>
        </Card>
        <Card title="Real Android implementation (permission-based)">
          <ul className="space-y-3">{APIS.map(([k, v]) => <li key={k} className="text-sm"><b className="text-slate-100">{k}</b><p className="text-slate-300">{v}</p></li>)}</ul>
        </Card>
        <Card title="Simulator vs. real device" className="lg:col-span-2">
          <div className="overflow-x-auto"><table className="w-full min-w-[560px] text-left text-sm">
            <thead className="text-[11px] uppercase tracking-wider text-slate-400"><tr><th className="py-2">Aspect</th><th>This browser simulator</th><th>Real Android app</th></tr></thead>
            <tbody className="text-slate-300">
              {[['Event source', 'Random state machine', 'Android system broadcasts and APIs'], ['Permissions', 'None needed', 'Runtime and special-access permissions granted by the user'], ['Runs in background', 'Only while the tab is open', 'Foreground Service / WorkManager'], ['Storage', 'Browser localStorage', 'App-private files / SQLite'], ['Dropbox', 'Real API (live mode) or simulated (demo)', 'Dropbox SDK + OAuth in a Custom Tab'], ['Data monitored', 'Fake, non-sensitive', 'Only what Android permits and the user consents to']].map(r => <tr key={r[0]} className="border-t border-white/5"><td className="py-2 pr-4 font-medium text-slate-100">{r[0]}</td><td className="pr-4">{r[1]}</td><td>{r[2]}</td></tr>)}
            </tbody></table></div>
        </Card>
        <Card title="Privacy & ethics" className="lg:col-span-2" icon={<ShieldCheck size={16} />}>
          <p className="text-sm leading-relaxed text-slate-300">Android Logger records only system-level, non-sensitive events. It never captures keystrokes, messages, passwords, call contents or other private data. Any real deployment must obtain informed user consent, show a persistent notification while logging, comply with Google Play policy and local privacy law, and let the user view, export and delete their data. Uploading to Dropbox here always requires an explicit OAuth authorization by the account owner.</p>
        </Card>
      </div>
    </>
  )
}

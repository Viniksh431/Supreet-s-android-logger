import { Battery, BatteryCharging, Bluetooth, Lock, LockOpen, Pause, Play, Plus, Smartphone, Square, Trash2, Wifi, WifiOff } from 'lucide-react'
import { useStore } from '../lib/store'
import { Card, PageHeader, Pill } from '../components/ui'
import LiveFeed from '../components/LiveFeed'
import { APPS } from '../lib/generator'
import { fmtDuration } from '../lib/format'

export function LoggerButtons({ compact = false }: { compact?: boolean }) {
  const { status, startLogger, stopLogger, pauseLogger, resumeLogger, clearLogs, generateSample } = useStore()
  const s = compact ? '!px-3 !py-1.5' : ''
  return (
    <div className="flex flex-wrap gap-2">
      <button className={`btn-primary ${s}`} onClick={startLogger} disabled={status !== 'stopped'}><Play size={15} />Start</button>
      <button className={`btn-ghost ${s}`} onClick={pauseLogger} disabled={status !== 'running'}><Pause size={15} />Pause</button>
      <button className={`btn-ghost ${s}`} onClick={resumeLogger} disabled={status !== 'paused'}><Play size={15} />Resume</button>
      <button className={`btn-ghost ${s}`} onClick={stopLogger} disabled={status === 'stopped'}><Square size={15} />Stop</button>
      <button className={`btn-ghost ${s}`} onClick={() => generateSample()}><Plus size={15} />Generate Sample Activity</button>
      <button className={`btn-danger ${s}`} onClick={clearLogs}><Trash2 size={15} />Clear Logs</button>
    </div>
  )
}

export default function LoggerControl() {
  const { status, device, startedAt, now, settings, analytics: a } = useStore()
  const fg = APPS.find(x => x.pkg === device.foreground)
  const Row = ({ k, v }: { k: string; v: React.ReactNode }) => (
    <div className="flex items-center justify-between border-b border-white/5 py-2 text-sm last:border-0"><span className="text-slate-400">{k}</span><span className="text-slate-100">{v}</span></div>
  )
  return (
    <>
      <PageHeader title="Logger Control" subtitle="Control the background logging service and watch the simulated device state change as events are generated." />
      <Card title="Logging service" icon={<Smartphone size={16} />} action={
        status === 'running' ? <Pill tone="good" pulse>Running</Pill> : status === 'paused' ? <Pill tone="warn">Paused</Pill> : <Pill tone="idle">Stopped</Pill>}>
        <LoggerButtons />
        <div className="mt-4 grid gap-x-8 sm:grid-cols-3">
          <Row k="Uptime" v={startedAt ? fmtDuration(now - startedAt) : '—'} />
          <Row k="Generation interval" v={`${settings.refreshIntervalSec}s`} />
          <Row k="Observed rate" v={`${(a.lastHourPerMinute).toFixed(2)} events/min (last hour)`} />
        </div>
        <p className="mt-3 text-xs text-slate-400">Pause suspends the event timer without stopping the service; Stop terminates it. Every lifecycle change is itself logged, like a real Android service.</p>
      </Card>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card title="Simulated device state">
          <div className="mx-auto mb-4 flex w-48 flex-col items-center rounded-[28px] border-4 border-slate-600/60 bg-black/40 p-4">
            <div className="mb-3 h-1.5 w-14 rounded-full bg-slate-600" />
            <div className={`flex h-40 w-full flex-col items-center justify-center rounded-xl text-center transition ${device.screenOn ? 'bg-gradient-to-b from-sky-500/30 to-emerald-500/20' : 'bg-slate-900'}`}>
              {!device.screenOn ? <span className="text-xs text-slate-500">Screen off</span>
                : device.locked ? <><Lock className="mb-1 text-slate-200" size={22} /><span className="text-xs text-slate-200">Locked</span></>
                : <><LockOpen className="mb-1 text-emerald-300" size={22} /><span className="px-2 text-xs font-medium text-white">{fg ? fg.name : 'Home screen'}</span></>}
            </div>
            <div className="mt-3 flex items-center gap-3 text-slate-300">
              {device.wifi ? <Wifi size={15} /> : <WifiOff size={15} className="text-slate-500" />}
              <Bluetooth size={15} className={device.bluetooth ? 'text-sky-300' : 'text-slate-600'} />
              {device.charging ? <BatteryCharging size={16} className="text-emerald-300" /> : <Battery size={16} />}
              <span className="text-[11px] tabular-nums">{device.battery}%</span>
            </div>
          </div>
          <Row k="Screen" v={device.screenOn ? 'ON' : 'OFF'} />
          <Row k="Keyguard" v={device.locked ? 'Locked' : 'Unlocked'} />
          <Row k="Foreground app" v={fg ? `${fg.name} (${fg.pkg})` : 'None'} />
          <Row k="Wi-Fi" v={device.wifi ? `Connected · ${device.ssid}` : 'Disconnected'} />
          <Row k="Bluetooth" v={device.bluetooth ? 'Enabled' : 'Disabled'} />
          <Row k="Network" v={device.network} />
          <Row k="Battery" v={`${device.battery}% ${device.charging ? '(charging)' : ''}`} />
          <Row k="Device uptime" v={fmtDuration(now - device.uptimeStart)} />
        </Card>
        <Card title="Live activity feed" action={status === 'running' ? <Pill tone="good" pulse>LIVE</Pill> : undefined}>
          <LiveFeed limit={20} height="max-h-[560px]" />
        </Card>
      </div>
      <p className="mt-4 text-xs text-slate-500">Privacy: only simulated, non-sensitive system events are generated. No keystrokes, messages, passwords, call contents or private data are ever captured.</p>
    </>
  )
}

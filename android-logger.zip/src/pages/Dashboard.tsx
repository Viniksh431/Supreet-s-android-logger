import { Activity, AppWindow, CalendarClock, Cloud, Database, HardDrive, Radio, Zap } from 'lucide-react'
import { useStore } from '../lib/store'
import { fmtBytes, fmtDateTime, relTime } from '../lib/format'
import { Card, PageHeader, StatCard, Pill } from '../components/ui'
import { AppUsageBar, Donut, HourlyBar, TrendLine } from '../components/Charts'
import LiveFeed from '../components/LiveFeed'
import { LoggerButtons } from './LoggerControl'

export default function Dashboard() {
  const { analytics: a, status, settings, connected, now, device } = useStore()
  const lastSync = a.sync.lastTs
  const dbxTone = connected ? (settings.demoMode ? 'warn' : 'good') : 'idle'
  return (
    <>
      <PageHeader title="System Overview" subtitle="Real-time view of simulated Android activity, calculated live from the stored log data.">
        <LoggerButtons compact />
      </PageHeader>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Activities logged" value={a.total.toLocaleString()} hint={`${a.avgPerMinute.toFixed(2)} events / min avg`} icon={<Activity size={16} />} />
        <StatCard label="Applications simulated" value={a.uniqueApps} hint={a.topApp ? `Top: ${a.topApp.name}` : 'No app activity yet'} icon={<AppWindow size={16} />} />
        <StatCard label="Log entries today" value={a.today.toLocaleString()} hint={`${a.avgPerDay.toFixed(0)} / day avg`} icon={<CalendarClock size={16} />} />
        <StatCard label="Log storage used" value={fmtBytes(a.logBytes)} hint={`${a.total ? fmtBytes(Math.round(a.logBytes / a.total)) : '0 B'} per entry`} icon={<HardDrive size={16} />} />
        <StatCard label="Last synchronization" value={<span className="text-lg">{relTime(lastSync, now)}</span>} hint={lastSync ? fmtDateTime(lastSync) : 'No successful sync yet'} icon={<Cloud size={16} />} />
        <StatCard label="Dropbox" value={<span className="text-lg">{connected ? (settings.demoMode ? 'Demo mode' : 'Connected') : 'Disconnected'}</span>} hint={settings.demoMode ? 'Simulated – no real uploads' : 'Live OAuth 2.0'} tone={dbxTone === 'idle' ? 'default' : dbxTone} icon={<Database size={16} />} />
        <StatCard label="Logger status" value={<span className="text-lg capitalize">{status}</span>} hint={`Interval ${settings.refreshIntervalSec}s`} tone={status === 'running' ? 'good' : status === 'paused' ? 'warn' : 'default'} icon={<Radio size={16} />} />
        <StatCard label="Simulated battery" value={`${device.battery}%`} hint={device.charging ? 'Charging' : 'On battery'} tone={device.battery <= 20 ? 'bad' : 'good'} icon={<Zap size={16} />} />
      </div>

      <div className="mt-6 grid gap-4 xl:grid-cols-3">
        <Card title="Activity distribution by hour of day" className="xl:col-span-2"><HourlyBar data={a.hourOfDay} /></Card>
        <Card title="Live activity feed" action={status === 'running' ? <Pill tone="good" pulse>LIVE</Pill> : <Pill tone="idle">{status}</Pill>}><LiveFeed limit={10} height="max-h-[290px]" /></Card>
      </div>
      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card title="Application usage (times opened)"><AppUsageBar data={a.appUsage} /></Card>
        <Card title="Daily activity trend (7 days)"><TrendLine data={a.perDay} xKey="label" yKey="count" name="Events" area /></Card>
        <Card title="Log generation (events per minute, last 30 min)"><TrendLine data={a.perMinute} xKey="label" yKey="count" name="Events" color={1} /></Card>
        <Card title="Storage consumption (cumulative KB)"><TrendLine data={a.storageByDay} xKey="label" yKey="kb" name="KB" color={2} area /></Card>
        <Card title="Event category distribution" className="lg:col-span-2"><Donut data={a.categories} /></Card>
      </div>
    </>
  )
}

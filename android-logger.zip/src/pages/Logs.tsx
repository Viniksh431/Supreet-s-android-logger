import { useEffect, useMemo, useState } from 'react'
import { ArrowDownUp, ChevronLeft, ChevronRight, Download, FileText, FileSpreadsheet, Search, Trash2, X } from 'lucide-react'
import { useStore } from '../lib/store'
import { CATEGORIES, SEVERITIES, type Category, type Severity } from '../lib/types'
import { dayKey, downloadFile, fmtDateTime, formatCsv, formatTxt } from '../lib/format'
import { Card, Empty, PageHeader, Pill, SeverityBadge, StatusBadge } from '../components/ui'
import LiveFeed from '../components/LiveFeed'

export default function Logs() {
  const { logs, deleteLog, clearLogs, notify, status, settings } = useStore()
  const [q, setQ] = useState('')
  const [cat, setCat] = useState<'all' | Category>('all')
  const [sev, setSev] = useState<'all' | Severity>('all')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [desc, setDesc] = useState(true)
  const [pageSize, setPageSize] = useState(25)
  const [page, setPage] = useState(0)
  const [feed, setFeed] = useState(false)

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase()
    const out = logs.filter(l => {
      if (cat !== 'all' && l.category !== cat) return false
      if (sev !== 'all' && l.severity !== sev) return false
      const dk = dayKey(l.ts)
      if (from && dk < from) return false
      if (to && dk > to) return false
      if (needle && !(`${l.id} ${l.source} ${l.description} ${l.category} ${l.status} ${l.severity} ${fmtDateTime(l.ts)}`.toLowerCase().includes(needle))) return false
      return true
    })
    out.sort((a, b) => (desc ? b.ts - a.ts || b.id.localeCompare(a.id) : a.ts - b.ts || a.id.localeCompare(b.id)))
    return out
  }, [logs, q, cat, sev, from, to, desc])

  const pages = Math.max(1, Math.ceil(filtered.length / pageSize))
  useEffect(() => { if (page >= pages) setPage(pages - 1) }, [pages, page])
  useEffect(() => { setPage(0) }, [q, cat, sev, from, to, pageSize])
  const rows = filtered.slice(page * pageSize, page * pageSize + pageSize)
  const isFiltered = !!(q || cat !== 'all' || sev !== 'all' || from || to)
  const reset = () => { setQ(''); setCat('all'); setSev('all'); setFrom(''); setTo('') }

  const stamp = () => dayKey(Date.now())
  const exportAs = (fmt: 'txt' | 'csv', data = filtered, label = isFiltered ? 'filtered ' : '') => {
    if (!data.length) { notify({ type: 'warning', title: 'Nothing to export', message: 'There are no log entries matching the current view.' }); return }
    const ordered = [...data].sort((a, b) => a.ts - b.ts)
    if (fmt === 'txt') downloadFile(`android_logger_${stamp()}.txt`, formatTxt(ordered), 'text/plain')
    else downloadFile(`android_logger_${stamp()}.csv`, formatCsv(ordered), 'text/csv')
    notify({ type: 'success', title: `Exported ${data.length} ${label}entries`, message: `Downloaded as ${fmt.toUpperCase()}.` })
  }
  const downloadComplete = () => exportAs(settings.exportFormat, logs, 'complete-log ')

  return (
    <>
      <PageHeader title="Log Management" subtitle={`${filtered.length.toLocaleString()} of ${logs.length.toLocaleString()} entries shown`}>
        <button className="btn-ghost" onClick={() => exportAs('txt')}><FileText size={15} />Export TXT</button>
        <button className="btn-ghost" onClick={() => exportAs('csv')}><FileSpreadsheet size={15} />Export CSV</button>
        <button className="btn-primary" onClick={downloadComplete}><Download size={15} />Download complete log</button>
        <button className="btn-danger" onClick={clearLogs}><Trash2 size={15} />Clear all</button>
      </PageHeader>

      <Card className="mb-4">
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-6">
          <div className="relative xl:col-span-2">
            <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input className="input !pl-9" placeholder="Search id, app, description…" value={q} onChange={e => setQ(e.target.value)} aria-label="Search logs" />
          </div>
          <select className="input" value={cat} onChange={e => setCat(e.target.value as any)} aria-label="Filter by category">
            <option value="all">All categories</option>{CATEGORIES.map(c => <option key={c}>{c}</option>)}
          </select>
          <select className="input" value={sev} onChange={e => setSev(e.target.value as any)} aria-label="Filter by severity">
            <option value="all">All severities</option>{SEVERITIES.map(c => <option key={c}>{c}</option>)}
          </select>
          <input type="date" className="input" value={from} max={to || undefined} onChange={e => setFrom(e.target.value)} aria-label="From date" title="From date" />
          <input type="date" className="input" value={to} min={from || undefined} onChange={e => setTo(e.target.value)} aria-label="To date" title="To date" />
        </div>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <button className="btn-ghost !px-2.5 !py-1.5 !text-xs" onClick={() => setDesc(d => !d)}><ArrowDownUp size={13} />Timestamp: {desc ? 'newest first' : 'oldest first'}</button>
            {isFiltered && <button className="btn-ghost !px-2.5 !py-1.5 !text-xs" onClick={reset}><X size={13} />Reset filters</button>}
          </div>
          <label className="flex items-center gap-2">Rows
            <select className="input !w-auto !py-1" value={pageSize} onChange={e => setPageSize(+e.target.value)}>{[10, 25, 50, 100].map(n => <option key={n}>{n}</option>)}</select>
          </label>
          <button className="btn-ghost !px-2.5 !py-1.5 !text-xs" onClick={() => setFeed(f => !f)}>{feed ? 'Hide' : 'Show'} live feed</button>
        </div>
      </Card>

      {feed && <Card title="Live activity feed" className="mb-4" action={status === 'running' ? <Pill tone="good" pulse>LIVE</Pill> : <Pill tone="idle">{status}</Pill>}><LiveFeed limit={8} height="max-h-[300px]" /></Card>}

      <Card className="!p-0 overflow-hidden">
        {rows.length === 0 ? (
          <Empty icon={<Search size={20} />} title={logs.length ? 'No logs match your filters' : 'No logs stored'} text={logs.length ? 'Try clearing a filter or widening the date range.' : 'Start the logger or generate sample activity to create entries.'} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[980px] text-left text-sm">
              <thead className="border-b border-white/10 bg-white/5 text-[11px] uppercase tracking-wider text-slate-400">
                <tr>{['Log ID', 'Timestamp', 'Category', 'Source', 'Description', 'Status', 'Severity', ''].map(h => <th key={h} className="px-4 py-3 font-medium">{h}</th>)}</tr>
              </thead>
              <tbody>
                {rows.map(l => (
                  <tr key={l.id} className="border-b border-white/5 transition hover:bg-white/5">
                    <td className="whitespace-nowrap px-4 py-2.5 font-mono text-xs text-slate-300">{l.id}</td>
                    <td className="whitespace-nowrap px-4 py-2.5 font-mono text-xs text-slate-300">{fmtDateTime(l.ts)}</td>
                    <td className="px-4 py-2.5 text-slate-200">{l.category}</td>
                    <td className="max-w-[180px] truncate px-4 py-2.5 font-mono text-xs text-slate-400" title={l.source}>{l.source}</td>
                    <td className="px-4 py-2.5 text-slate-100">{l.description}</td>
                    <td className="px-4 py-2.5"><StatusBadge s={l.status} /></td>
                    <td className="px-4 py-2.5"><SeverityBadge s={l.severity} /></td>
                    <td className="px-2 py-2.5"><button className="rounded-md p-1.5 text-slate-500 hover:bg-red-500/10 hover:text-red-300" onClick={() => deleteLog(l.id)} aria-label={`Delete ${l.id}`} title="Delete this entry"><Trash2 size={14} /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <div className="flex items-center justify-between border-t border-white/10 px-4 py-3 text-xs text-slate-400">
          <span>Page {page + 1} of {pages}</span>
          <div className="flex gap-2">
            <button className="btn-ghost !px-2 !py-1" disabled={page === 0} onClick={() => setPage(p => p - 1)} aria-label="Previous page"><ChevronLeft size={15} /></button>
            <button className="btn-ghost !px-2 !py-1" disabled={page >= pages - 1} onClick={() => setPage(p => p + 1)} aria-label="Next page"><ChevronRight size={15} /></button>
          </div>
        </div>
      </Card>
    </>
  )
}

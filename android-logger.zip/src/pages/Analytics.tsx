import { useStore } from '../lib/store'
import { fmtBytes, fmtDateTime } from '../lib/format'
import { Card, PageHeader } from '../components/ui'
import { AppUsageBar, Donut, HourlyBar, SeverityBars, TrendLine } from '../components/Charts'

export default function Analytics() {
  const { analytics: a } = useStore()
  const rows: [string, string, string][] = [
    ['1', 'Total events generated', a.total.toLocaleString()],
    ['2', 'Events per hour (average)', a.avgPerHour.toFixed(1)],
    ['3', 'Events per day (average)', a.avgPerDay.toFixed(0)],
    ['4', 'Application usage frequency', a.appUsage.length ? a.appUsage.slice(0, 3).map(x => `${x.name} ${x.count}`).join(' · ') : '—'],
    ['5', 'Most frequently used application', a.topApp ? `${a.topApp.name} (${a.topApp.count} launches)` : '—'],
    ['6', 'Average events per minute', a.avgPerMinute.toFixed(3)],
    ['7', 'Total log file size', `${fmtBytes(a.logBytes)} (${a.logBytes.toLocaleString()} bytes)`],
    ['8', 'Total synchronization size', `${fmtBytes(a.sync.bytes)} (live ${fmtBytes(a.sync.live.bytes)} · demo ${fmtBytes(a.sync.demo.bytes)})`],
    ['9', 'Sync attempts: successful vs failed', `${a.sync.success} successful · ${a.sync.failed} failed${a.sync.partial ? ` · ${a.sync.partial} partial` : ''} of ${a.sync.total}`],
    ['10', 'Event category distribution', a.categories.slice(0, 4).map(c => `${c.name} ${((c.count / Math.max(1, a.total)) * 100).toFixed(0)}%`).join(' · ') || '—'],
  ]
  return (
    <>
      <PageHeader title="Log Analytics" subtitle="Every figure below is computed from the stored log entries and sync records — nothing is hardcoded." />
      <Card title="Computed metrics" className="mb-4">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <tbody>
              {rows.map(([n, k, v]) => (
                <tr key={n} className="border-b border-white/5 last:border-0">
                  <td className="w-10 py-2.5 text-xs text-slate-500">{n}</td>
                  <td className="py-2.5 pr-4 text-slate-300">{k}</td>
                  <td className="py-2.5 text-right font-medium tabular-nums text-white">{v}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-xs text-slate-400">
          Data span: {a.firstTs ? `${fmtDateTime(a.firstTs)} → ${fmtDateTime(a.lastTs!)}` : 'no data'} ({a.spanMinutes.toFixed(0)} min).
          Average rates = total ÷ elapsed time between the first entry and now. Log size = byte length of the TXT-formatted lines.
          Sync figures count Demo-Mode (simulated) and Live (real Dropbox) runs separately.
        </p>
      </Card>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Events per hour (last 24 hours)"><TrendLine data={a.last24h} xKey="label" yKey="count" name="Events" area /></Card>
        <Card title="Events per day (last 7 days)"><TrendLine data={a.perDay} xKey="label" yKey="count" name="Events" color={1} /></Card>
        <Card title="Hour-of-day distribution"><HourlyBar data={a.hourOfDay} /></Card>
        <Card title="Application launch frequency"><AppUsageBar data={a.appUsage} /></Card>
        <Card title="Category distribution"><Donut data={a.categories} /></Card>
        <Card title="Severity distribution"><SeverityBars data={a.severities} /></Card>
      </div>
    </>
  )
}

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import {
  DEFAULT_SETTINGS, type DeviceState, type DropboxAccount, type DropboxTokens, type LogEntry, type LoggerStatus,
  type RemoteFile, type Settings, type SyncFile, type SyncMode, type SyncProgress, type SyncRecord,
} from './types'
import { generateBurst, generateHistory, initialDevice, nextEvents, type RawEvent } from './generator'
import { computeAnalytics, type Analytics } from './analytics'
import { byteLen, dayKey, formatCsv, formatTxt } from './format'
import * as dbx from './dropbox'

/* ---------------- persistence helpers ---------------- */
const K = {
  logs: 'androidlogger.logs', settings: 'androidlogger.settings', syncs: 'androidlogger.syncs',
  remote: 'androidlogger.remote', dropbox: 'androidlogger.dropbox', meta: 'androidlogger.meta', demo: 'androidlogger.demo',
}
function load<T>(key: string, fallback: T): T {
  try { const s = localStorage.getItem(key); return s ? (JSON.parse(s) as T) : fallback } catch { return fallback }
}
let quotaWarned = false
function save(key: string, value: unknown, onFail?: () => void) {
  try { localStorage.setItem(key, JSON.stringify(value)) } catch {
    if (!quotaWarned) { quotaWarned = true; onFail?.() }
  }
}
interface Meta { logCounter: number; syncCounter: number; fileSeq: number; seeded: boolean }

/* ---------------- toasts + confirm ---------------- */
export interface Toast { id: number; type: 'success' | 'error' | 'info' | 'warning'; title: string; message?: string }
interface ConfirmOpts { title: string; message: string; confirmLabel?: string; danger?: boolean }

interface Store {
  logs: LogEntry[]
  settings: Settings
  updateSettings: (p: Partial<Settings>) => void
  resetSettings: () => void
  status: LoggerStatus
  startedAt: number | null
  device: DeviceState
  startLogger: () => void
  stopLogger: () => void
  pauseLogger: () => void
  resumeLogger: () => void
  clearLogs: () => Promise<void>
  deleteLog: (id: string) => void
  generateSample: (count?: number) => void
  analytics: Analytics
  now: number
  // dropbox
  syncs: SyncRecord[]
  remoteFiles: RemoteFile[]
  progress: SyncProgress | null
  demoConnected: boolean
  live: DropboxTokens | null
  account: DropboxAccount | null
  connected: boolean
  connectDropbox: () => Promise<void>
  disconnectDropbox: () => Promise<void>
  runSync: (kind: 'upload' | 'sync', trigger?: 'manual' | 'auto') => Promise<void>
  clearSyncHistory: () => Promise<void>
  // ui
  toasts: Toast[]
  notify: (t: Omit<Toast, 'id'>) => void
  dismissToast: (id: number) => void
  confirm: (o: ConfirmOpts) => Promise<boolean>
  confirmState: (ConfirmOpts & { resolve: (v: boolean) => void }) | null
  storageUsed: number
}

const Ctx = createContext<Store | null>(null)
export const useStore = () => {
  const s = useContext(Ctx)
  if (!s) throw new Error('useStore outside provider')
  return s
}
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms))

export function StoreProvider({ children }: { children: ReactNode }) {
  /* ---- state ---- */
  const [settings, setSettings] = useState<Settings>(() => ({ ...DEFAULT_SETTINGS, ...load<Partial<Settings>>(K.settings, {}) }))
  const metaRef = useRef<Meta>(load<Meta>(K.meta, { logCounter: 0, syncCounter: 0, fileSeq: 0, seeded: false }))
  const [logs, setLogs] = useState<LogEntry[]>(() => {
    const m = metaRef.current
    if (!m.seeded) {
      // First launch: seed 7 days of realistic sample history so analytics are meaningful immediately.
      const raw = generateHistory(7).sort((a, b) => a.ts - b.ts)
      const seeded = raw.map(r => ({ ...r, id: `LOG-${String(++m.logCounter).padStart(6, '0')}` }))
      m.seeded = true
      save(K.meta, m); save(K.logs, seeded)
      return seeded
    }
    return load<LogEntry[]>(K.logs, [])
  })
  const [status, setStatus] = useState<LoggerStatus>('stopped')
  const [startedAt, setStartedAt] = useState<number | null>(null)
  const [device, setDevice] = useState<DeviceState>(() => initialDevice())
  const deviceRef = useRef<DeviceState>(device)
  const [syncs, setSyncs] = useState<SyncRecord[]>(() => load(K.syncs, []))
  const [remoteFiles, setRemoteFiles] = useState<RemoteFile[]>(() => load(K.remote, []))
  const [progress, setProgress] = useState<SyncProgress | null>(null)
  const [demoConnected, setDemoConnected] = useState<boolean>(() => load(K.demo, false))
  const [live, setLive] = useState<DropboxTokens | null>(() => load<DropboxTokens | null>(K.dropbox, null))
  const [toasts, setToasts] = useState<Toast[]>([])
  const [confirmState, setConfirmState] = useState<Store['confirmState']>(null)
  const [now, setNow] = useState(Date.now())
  const syncingRef = useRef(false)
  const logsRef = useRef<LogEntry[]>([])
  logsRef.current = logs
  const toastId = useRef(0)

  /* ---- ui helpers ---- */
  const dismissToast = useCallback((id: number) => setToasts(t => t.filter(x => x.id !== id)), [])
  const notify = useCallback((t: Omit<Toast, 'id'>) => {
    const id = ++toastId.current
    setToasts(x => [...x.slice(-3), { ...t, id }])
    setTimeout(() => dismissToast(id), t.type === 'error' ? 7000 : 4000)
  }, [dismissToast])
  const confirm = useCallback((o: ConfirmOpts) => new Promise<boolean>(resolve => {
    setConfirmState({ ...o, resolve: (v: boolean) => { setConfirmState(null); resolve(v) } })
  }), [])

  /* ---- settings ---- */
  const updateSettings = useCallback((p: Partial<Settings>) => setSettings(s => ({ ...s, ...p })), [])
  const resetSettings = useCallback(() => setSettings({ ...DEFAULT_SETTINGS }), [])
  useEffect(() => { save(K.settings, settings) }, [settings])
  useEffect(() => {
    document.documentElement.classList.toggle('dark', settings.theme === 'dark')
    document.documentElement.classList.toggle('light', settings.theme === 'light')
  }, [settings.theme])

  /* ---- log append (with retention + max entries) ---- */
  const settingsRef = useRef(settings); settingsRef.current = settings
  const appendRaw = useCallback((raws: RawEvent[]) => {
    if (!raws.length) return
    const m = metaRef.current
    const entries: LogEntry[] = raws.map(r => ({ ...r, id: `LOG-${String(++m.logCounter).padStart(6, '0')}` }))
    setLogs(prev => applyRetention([...prev, ...entries], settingsRef.current))
  }, [])
  const sys = useCallback((description: string, severity: RawEvent['severity'] = 'INFO', status: RawEvent['status'] = 'Success', category: RawEvent['category'] = 'System', source = 'AndroidLogger.Service') => {
    appendRaw([{ ts: Date.now(), category, source, description, severity, status }])
  }, [appendRaw])

  // persist logs (debounced)
  useEffect(() => {
    const t = setTimeout(() => {
      save(K.logs, logs, () => notify({ type: 'warning', title: 'Browser storage is full', message: 'Lower the max log entries in Settings or clear old logs.' }))
      save(K.meta, metaRef.current)
    }, 600)
    return () => clearTimeout(t)
  }, [logs, notify])
  useEffect(() => { save(K.syncs, syncs) }, [syncs])
  useEffect(() => { save(K.remote, remoteFiles) }, [remoteFiles])
  useEffect(() => { save(K.demo, demoConnected) }, [demoConnected])
  useEffect(() => { save(K.dropbox, live) }, [live])

  // apply retention when settings change
  useEffect(() => { setLogs(prev => { const n = applyRetention(prev, settings); return n.length === prev.length ? prev : n }) }, [settings.retentionDays, settings.maxEntries])

  // clock for relative times
  useEffect(() => { const i = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(i) }, [])

  /* ---- logger engine (event-driven timer) ---- */
  useEffect(() => {
    if (status !== 'running') return
    const tick = () => {
      const burst = Math.random() < 0.3 ? 2 : 1
      const out: RawEvent[] = []
      for (let i = 0; i < burst; i++) out.push(...nextEvents(deviceRef.current, Date.now() + i))
      deviceRef.current = { ...deviceRef.current }
      setDevice(deviceRef.current)
      appendRaw(out)
    }
    const id = setInterval(tick, Math.max(1, settings.refreshIntervalSec) * 1000)
    return () => clearInterval(id)
  }, [status, settings.refreshIntervalSec, appendRaw])

  const startLogger = useCallback(() => {
    setStatus('running'); setStartedAt(Date.now())
    sys('Logger service started')
    notify({ type: 'success', title: 'Logger started', message: 'Simulated Android events are now being generated.' })
  }, [sys, notify])
  const stopLogger = useCallback(() => {
    sys('Logger service stopped', 'WARN')
    setStatus('stopped'); setStartedAt(null)
    notify({ type: 'info', title: 'Logger stopped' })
  }, [sys, notify])
  const pauseLogger = useCallback(() => { sys('Logger service paused'); setStatus('paused'); notify({ type: 'info', title: 'Logger paused', message: 'Event generation is suspended.' }) }, [sys, notify])
  const resumeLogger = useCallback(() => { setStatus('running'); sys('Logger service resumed'); notify({ type: 'success', title: 'Logger resumed' }) }, [sys, notify])

  // auto-start on load
  const autoStarted = useRef(false)
  useEffect(() => {
    if (autoStarted.current) return
    autoStarted.current = true
    if (settings.autoLogging) { setStatus('running'); setStartedAt(Date.now()); sys('Logger service started (auto-start on load)') }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const clearLogs = useCallback(async () => {
    const ok = await confirm({ title: 'Clear all logs?', message: `This permanently deletes all ${logs.length} stored log entries from this browser. Files already uploaded to Dropbox are not affected.`, confirmLabel: 'Clear all logs', danger: true })
    if (!ok) return
    setLogs([])
    notify({ type: 'success', title: 'Logs cleared', message: 'All log entries were removed.' })
  }, [confirm, logs.length, notify])
  const deleteLog = useCallback((id: string) => {
    setLogs(prev => prev.filter(l => l.id !== id))
    notify({ type: 'info', title: 'Log entry deleted', message: id })
  }, [notify])
  const generateSample = useCallback((count = 25) => {
    const raws = generateBurst(deviceRef.current, count)
    deviceRef.current = { ...deviceRef.current }
    setDevice(deviceRef.current)
    appendRaw(raws)
    notify({ type: 'success', title: 'Sample activity generated', message: `${raws.length} realistic log entries were inserted.` })
  }, [appendRaw, notify])

  /* ---- analytics (derived from real data) ---- */
  const analytics = useMemo(() => computeAnalytics(logs, syncs, now), [logs, syncs, Math.floor(now / 5000)]) // eslint-disable-line
  const storageUsed = useMemo(() => {
    let n = 0
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i)!; if (k.startsWith('androidlogger.')) n += (k.length + (localStorage.getItem(k)?.length ?? 0)) * 2 } } catch { /* ignore */ }
    return n
  }, [logs, syncs, remoteFiles])

  /* ---- Dropbox: OAuth redirect handling ---- */
  const account = settings.demoMode
    ? (demoConnected ? { name: 'Demo User (simulated)', email: 'demo.user@androidlogger.local', accountId: 'dbid:DEMO-SIMULATED', accountType: 'demo' } : null)
    : live?.account ?? null
  const connected = settings.demoMode ? demoConnected : !!live

  const oauthHandled = useRef(false)
  useEffect(() => {
    if (oauthHandled.current) return
    oauthHandled.current = true
    const pending = dbx.pendingAuthRedirect()
    if (!pending) return
    const appKey = settingsRef.current.dropboxAppKey
    ;(async () => {
      try {
        if (pending.error) throw new Error(pending.errorDescription || pending.error)
        if (!pending.code) throw new Error('No authorization code returned by Dropbox.')
        const tokens = await dbx.exchangeCode(appKey, pending.code)
        const acct = await dbx.fetchAccount(tokens.accessToken)
        setLive({ ...tokens, account: acct })
        updateSettings({ demoMode: false })
        sys(`Dropbox account authorized: ${acct.name}`, 'INFO', 'Success', 'Network', 'Dropbox Sync Service')
        notify({ type: 'success', title: 'Dropbox connected', message: `Authorized as ${acct.name}. Live uploads are enabled.` })
      } catch (e) {
        notify({ type: 'error', title: 'Dropbox authorization failed', message: (e as Error).message })
      } finally {
        dbx.finishRedirectCleanup()
        window.dispatchEvent(new HashChangeEvent('hashchange'))
      }
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const connectDropbox = useCallback(async () => {
    const s = settingsRef.current
    if (s.demoMode) {
      setDemoConnected(true)
      sys('Dropbox DEMO connection established (simulated, no network call)', 'INFO', 'Success', 'Network', 'Dropbox Sync Service')
      notify({ type: 'info', title: 'Demo Mode connected', message: 'This is a simulated Dropbox account. No real data leaves your browser.' })
      return
    }
    if (!s.dropboxAppKey.trim()) {
      notify({ type: 'error', title: 'Dropbox App key missing', message: 'Add your App key in Settings → Dropbox Configuration, or switch on Demo Mode.' })
      return
    }
    const ok = await confirm({
      title: 'Authorize Dropbox access?',
      message: 'You will be redirected to dropbox.com to explicitly grant Android Logger permission to read your account name and write log files to your Dropbox. You can revoke access at any time.',
      confirmLabel: 'Continue to Dropbox',
    })
    if (!ok) return
    try { await dbx.beginAuthorization(s.dropboxAppKey.trim(), window.location.hash || '#/dropbox') }
    catch (e) { notify({ type: 'error', title: 'Could not start authorization', message: (e as Error).message }) }
  }, [confirm, notify, sys])

  const disconnectDropbox = useCallback(async () => {
    const demo = settingsRef.current.demoMode
    const ok = await confirm({ title: 'Disconnect Dropbox?', message: demo ? 'The simulated Dropbox connection will be removed.' : 'The access token will be revoked and removed from this browser. Files already in Dropbox stay there.', confirmLabel: 'Disconnect', danger: true })
    if (!ok) return
    if (demo) setDemoConnected(false)
    else { if (live) await dbx.revokeToken(live.accessToken); setLive(null) }
    sys(`Dropbox ${demo ? 'demo ' : ''}connection removed`, 'INFO', 'Success', 'Network', 'Dropbox Sync Service')
    notify({ type: 'info', title: 'Dropbox disconnected' })
  }, [confirm, live, notify, sys])

  /* ---- Dropbox: sync engine ---- */
  const runSync = useCallback(async (kind: 'upload' | 'sync', trigger: 'manual' | 'auto' = 'manual') => {
    if (syncingRef.current) { if (trigger === 'manual') notify({ type: 'warning', title: 'Sync already running' }); return }
    const s = settingsRef.current
    const mode: SyncMode = s.demoMode ? 'demo' : 'live'
    if (mode === 'demo' && !demoConnected) { if (trigger === 'manual') notify({ type: 'error', title: 'Not connected', message: 'Connect to Dropbox (Demo Mode) first.' }); return }
    if (mode === 'live' && !live) { if (trigger === 'manual') notify({ type: 'error', title: 'Not connected', message: 'Connect your Dropbox account first.' }); return }
    syncingRef.current = true
    const t0 = Date.now()
    const label = mode === 'demo' ? '[DEMO]' : '[LIVE]'
    sys(`${label} Dropbox ${kind === 'sync' ? 'sync' : 'upload'} started (${trigger})`, 'INFO', 'Pending', 'Network', 'Dropbox Sync Service')
    setProgress({ phase: 'preparing', pct: 4, message: 'Preparing log files…', mode })

    // ---- prepare files ----
    const snapshot = logsRef.current
    const an = computeAnalytics(snapshot, syncs, Date.now())
    const seq = String(++metaRef.current.fileSeq).padStart(3, '0')
    const files: { path: string; content: string }[] = []
    const wantTxt = kind === 'sync' || s.exportFormat === 'txt'
    const wantCsv = kind === 'sync' || s.exportFormat === 'csv'
    if (wantTxt) files.push({ path: `/AndroidLogger/Logs/activity_log_${seq}.txt`, content: formatTxt(snapshot) })
    if (wantCsv) files.push({ path: `/AndroidLogger/Logs/activity_log_${seq}.csv`, content: formatCsv(snapshot) })
    if (kind === 'sync') {
      files.push({
        path: '/AndroidLogger/Reports/daily_report.json',
        content: JSON.stringify({
          generatedAt: new Date().toISOString(),
          source: 'Android Logger (browser simulator)',
          totalEvents: an.total, eventsToday: an.today, avgEventsPerMinute: +an.avgPerMinute.toFixed(3),
          topApplication: an.topApp, applicationUsage: an.appUsage,
          categoryDistribution: an.categories, severityDistribution: an.severities,
          eventsPerHourOfDay: an.hourOfDay, eventsPerDay: an.perDay.map(d => ({ day: d.day, count: d.count })),
          logSizeBytes: an.logBytes,
        }, null, 2),
      })
    }
    await sleep(mode === 'demo' ? 700 : 150)
    setProgress({ phase: 'uploading', pct: 12, message: `Prepared ${files.length} file(s), ${(files.reduce((a, f) => a + byteLen(f.content), 0) / 1024).toFixed(1)} KB total`, mode })
    await sleep(mode === 'demo' ? 400 : 100)

    // ---- upload ----
    const results: SyncFile[] = []
    let token = live
    let fatal: string | undefined
    try {
      for (let i = 0; i < files.length; i++) {
        const f = files[i]
        const size = byteLen(f.content)
        const base = 12 + (i / files.length) * 80
        const span = 80 / files.length
        setProgress({ phase: 'uploading', pct: base, message: `Uploading ${f.path}`, mode })
        try {
          if (mode === 'demo') {
            const steps = 8
            for (let k = 1; k <= steps; k++) {
              await sleep(120 + Math.random() * 120)
              setProgress({ phase: 'uploading', pct: base + (k / steps) * span, message: `Uploading ${f.path} (${Math.round((k / steps) * 100)}%)`, mode })
            }
            if (s.demoFailures && Math.random() < 0.25) throw new Error('Simulated network timeout (demo failure injection)')
          } else {
            if (token && token.expiresAt - Date.now() < 60_000) {
              token = await dbx.refreshAccessToken(s.dropboxAppKey.trim(), token)
              setLive(token)
            }
            await dbx.uploadFile(token!.accessToken, f.path, f.content)
            setProgress({ phase: 'uploading', pct: base + span, message: `Uploaded ${f.path}`, mode })
          }
          results.push({ path: f.path, size, ok: true })
          setRemoteFiles(prev => [...prev.filter(r => !(r.path === f.path && r.mode === mode)), { path: f.path, size, ts: Date.now(), mode }])
        } catch (e) {
          results.push({ path: f.path, size, ok: false, error: (e as Error).message })
          if (mode === 'live' && /expired|invalid_access_token|401|refresh/i.test((e as Error).message)) { fatal = (e as Error).message; break }
        }
      }
    } catch (e) { fatal = (e as Error).message }

    setProgress({ phase: 'finalizing', pct: 97, message: 'Finalizing…', mode })
    await sleep(mode === 'demo' ? 400 : 100)
    const okCount = results.filter(r => r.ok).length
    const st: SyncRecord['status'] = okCount === files.length ? 'success' : okCount === 0 ? 'failed' : 'partial'
    const rec: SyncRecord = {
      id: `SYNC-${String(++metaRef.current.syncCounter).padStart(4, '0')}`,
      ts: Date.now(), mode, trigger, kind, files: results,
      bytes: results.filter(r => r.ok).reduce((a, r) => a + r.size, 0),
      status: st, durationMs: Date.now() - t0,
      error: fatal ?? results.find(r => !r.ok)?.error,
    }
    setSyncs(prev => [rec, ...prev].slice(0, 200))
    setProgress({ phase: 'finalizing', pct: 100, message: st === 'failed' ? 'Failed' : 'Complete', mode })
    sys(`${label} Dropbox ${kind === 'sync' ? 'sync' : 'upload'} ${st} (${okCount}/${files.length} files)${rec.error ? ': ' + rec.error : ''}`, st === 'success' ? 'INFO' : st === 'partial' ? 'WARN' : 'ERROR', st === 'success' ? 'Success' : 'Failed', 'Network', 'Dropbox Sync Service')
    notify({
      type: st === 'success' ? 'success' : st === 'partial' ? 'warning' : 'error',
      title: st === 'success'
        ? (mode === 'demo' ? 'Simulated sync complete (Demo Mode)' : 'Uploaded to Dropbox')
        : st === 'partial' ? 'Sync partially completed' : 'Sync failed',
      message: st === 'success'
        ? (mode === 'demo' ? `${okCount} file(s) simulated. Nothing was sent to Dropbox.` : `${okCount} file(s) uploaded to your Dropbox.`)
        : rec.error,
    })
    await sleep(900)
    setProgress(null)
    syncingRef.current = false
  }, [demoConnected, live, notify, sys, syncs])

  const clearSyncHistory = useCallback(async () => {
    const ok = await confirm({ title: 'Clear sync history?', message: 'Sync records and the simulated/recorded file list will be removed from this browser. Nothing is deleted from Dropbox.', confirmLabel: 'Clear history', danger: true })
    if (!ok) return
    setSyncs([]); setRemoteFiles([])
    notify({ type: 'info', title: 'Sync history cleared' })
  }, [confirm, notify])

  // auto sync
  const runSyncRef = useRef(runSync); runSyncRef.current = runSync
  useEffect(() => {
    if (!settings.autoSync) return
    const id = setInterval(() => runSyncRef.current('sync', 'auto'), settings.autoSyncMinutes * 60_000)
    return () => clearInterval(id)
  }, [settings.autoSync, settings.autoSyncMinutes])

  const value: Store = {
    logs, settings, updateSettings, resetSettings, status, startedAt, device,
    startLogger, stopLogger, pauseLogger, resumeLogger, clearLogs, deleteLog, generateSample,
    analytics, now, syncs, remoteFiles, progress, demoConnected, live, account, connected,
    connectDropbox, disconnectDropbox, runSync, clearSyncHistory,
    toasts, notify, dismissToast, confirm, confirmState, storageUsed,
  }
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

function applyRetention(list: LogEntry[], s: Settings): LogEntry[] {
  let out = list
  if (s.retentionDays > 0) {
    const cutoff = Date.now() - s.retentionDays * 86400_000
    out = out.filter(l => l.ts >= cutoff)
  }
  if (out.length > s.maxEntries) out = out.slice(out.length - s.maxEntries)
  return out
}
export { dayKey }

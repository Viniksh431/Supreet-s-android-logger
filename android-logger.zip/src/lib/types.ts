export type Severity = 'DEBUG' | 'INFO' | 'WARN' | 'ERROR' | 'CRITICAL'
export type EventStatus = 'Success' | 'Failed' | 'Pending'
export type Category =
  | 'Application' | 'Screen' | 'Security' | 'Wi-Fi' | 'Bluetooth'
  | 'Battery' | 'Power' | 'Network' | 'System'

export const CATEGORIES: Category[] = [
  'Application', 'Screen', 'Security', 'Wi-Fi', 'Bluetooth', 'Battery', 'Power', 'Network', 'System',
]
export const SEVERITIES: Severity[] = ['DEBUG', 'INFO', 'WARN', 'ERROR', 'CRITICAL']

export interface LogEntry {
  id: string            // unique log id, e.g. LOG-000123
  ts: number            // epoch ms
  category: Category
  source: string        // application package or system component
  description: string
  status: EventStatus
  severity: Severity
}

export type LoggerStatus = 'stopped' | 'running' | 'paused'
export type ExportFormat = 'txt' | 'csv'
export type Theme = 'dark' | 'light'

export interface Settings {
  refreshIntervalSec: number
  autoLogging: boolean
  autoSync: boolean
  autoSyncMinutes: number
  retentionDays: number      // 0 = keep forever
  maxEntries: number
  exportFormat: ExportFormat
  theme: Theme
  demoMode: boolean
  demoFailures: boolean      // inject random failures in demo mode
  dropboxAppKey: string
}

export const DEFAULT_SETTINGS: Settings = {
  refreshIntervalSec: 3,
  autoLogging: true,
  autoSync: false,
  autoSyncMinutes: 5,
  retentionDays: 30,
  maxEntries: 5000,
  exportFormat: 'txt',
  theme: 'dark',
  demoMode: true,
  demoFailures: false,
  dropboxAppKey: (import.meta.env.VITE_DROPBOX_APP_KEY as string | undefined) ?? '',
}

export interface DeviceState {
  screenOn: boolean
  locked: boolean
  wifi: boolean
  ssid: string | null
  bluetooth: boolean
  battery: number
  charging: boolean
  network: 'WIFI' | 'MOBILE' | 'NONE'
  foreground: string | null
  uptimeStart: number
}

export type SyncMode = 'demo' | 'live'
export interface SyncFile { path: string; size: number; ok: boolean; error?: string }
export interface SyncRecord {
  id: string
  ts: number
  mode: SyncMode
  trigger: 'manual' | 'auto'
  kind: 'upload' | 'sync'
  files: SyncFile[]
  bytes: number          // bytes successfully uploaded
  status: 'success' | 'failed' | 'partial'
  durationMs: number
  error?: string
}
export interface RemoteFile { path: string; size: number; ts: number; mode: SyncMode }

export interface DropboxAccount { name: string; email: string; accountId: string; accountType: string }
export interface DropboxTokens {
  accessToken: string
  refreshToken?: string
  expiresAt: number
  account?: DropboxAccount
}

export interface SyncProgress {
  phase: 'preparing' | 'uploading' | 'finalizing'
  pct: number
  message: string
  mode: SyncMode
}

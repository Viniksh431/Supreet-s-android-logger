/**
 * Dropbox integration — OAuth 2.0 Authorization Code flow with PKCE (no client secret in the browser)
 * and the Dropbox HTTP API v2. Docs: https://www.dropbox.com/developers/documentation/http/documentation
 */
import type { DropboxAccount, DropboxTokens } from './types'

const AUTH_URL = 'https://www.dropbox.com/oauth2/authorize'
const TOKEN_URL = 'https://api.dropboxapi.com/oauth2/token'
const ACCOUNT_URL = 'https://api.dropboxapi.com/2/users/get_current_account'
const UPLOAD_URL = 'https://content.dropboxapi.com/2/files/upload'
const REVOKE_URL = 'https://api.dropboxapi.com/2/auth/token/revoke'

const VERIFIER_KEY = 'androidlogger.pkce.verifier'
const STATE_KEY = 'androidlogger.pkce.state'

export const redirectUri = () => window.location.origin + '/'

function b64url(buf: ArrayBuffer | Uint8Array): string {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf)
  let s = ''
  bytes.forEach(b => (s += String.fromCharCode(b)))
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}
function randomString(len = 64): string {
  const a = new Uint8Array(len)
  crypto.getRandomValues(a)
  return b64url(a).slice(0, len)
}
async function challengeFor(verifier: string): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier))
  return b64url(digest)
}

/** Step 1: redirect the user to Dropbox's consent screen. */
export async function beginAuthorization(appKey: string, returnHash: string): Promise<void> {
  if (!window.crypto?.subtle) throw new Error('Web Crypto is unavailable. Serve the app from http://localhost or HTTPS.')
  const verifier = randomString(80)
  const state = randomString(24)
  ss('set', VERIFIER_KEY, verifier)
  ss('set', STATE_KEY, state + '|' + returnHash)
  const params = new URLSearchParams({
    client_id: appKey,
    response_type: 'code',
    code_challenge: await challengeFor(verifier),
    code_challenge_method: 'S256',
    token_access_type: 'offline',
    redirect_uri: redirectUri(),
    state,
    scope: 'account_info.read files.content.write files.content.read',
  })
  window.location.assign(`${AUTH_URL}?${params}`)
}

/** Step 2: called on page load. If Dropbox redirected back with ?code=…, exchange it for tokens. */
function ss(op: 'get' | 'set' | 'remove', key: string, val?: string): string | null {
  try {
    if (op === 'get') return sessionStorage.getItem(key)
    if (op === 'set') sessionStorage.setItem(key, val ?? '')
    else sessionStorage.removeItem(key)
  } catch { /* storage unavailable (sandboxed frame) */ }
  return null
}
export function pendingAuthRedirect(): { code?: string; error?: string; errorDescription?: string } | null {
  const q = new URLSearchParams(window.location.search)
  const stored = ss('get', STATE_KEY)
  if (!stored) return null
  const state = q.get('state')
  if (!state && !q.get('code') && !q.get('error')) return null
  if (state !== stored.split('|')[0]) return { error: 'state_mismatch', errorDescription: 'OAuth state did not match (possible CSRF). Authorization aborted.' }
  if (q.get('error')) return { error: q.get('error')!, errorDescription: q.get('error_description') ?? undefined }
  return { code: q.get('code') ?? undefined }
}
export function finishRedirectCleanup(): string {
  const returnHash = (ss('get', STATE_KEY) ?? '').split('|')[1] ?? '#/dropbox'
  ss('remove', STATE_KEY)
  history.replaceState(null, '', window.location.pathname + (returnHash || '#/dropbox'))
  return returnHash
}

export async function exchangeCode(appKey: string, code: string): Promise<DropboxTokens> {
  const verifier = ss('get', VERIFIER_KEY)
  if (!verifier) throw new Error('Missing PKCE verifier – please start the connection again.')
  const res = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code, grant_type: 'authorization_code', client_id: appKey,
      code_verifier: verifier, redirect_uri: redirectUri(),
    }),
  })
  ss('remove', VERIFIER_KEY)
  const j = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(j.error_description || j.error || `Token exchange failed (HTTP ${res.status})`)
  return { accessToken: j.access_token, refreshToken: j.refresh_token, expiresAt: Date.now() + (j.expires_in ?? 14400) * 1000 }
}

export async function refreshAccessToken(appKey: string, t: DropboxTokens): Promise<DropboxTokens> {
  if (!t.refreshToken) throw new Error('Access token expired and no refresh token is available. Reconnect Dropbox.')
  const res = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'refresh_token', refresh_token: t.refreshToken, client_id: appKey }),
  })
  const j = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(j.error_description || j.error || `Token refresh failed (HTTP ${res.status})`)
  return { ...t, accessToken: j.access_token, expiresAt: Date.now() + (j.expires_in ?? 14400) * 1000 }
}

export async function fetchAccount(accessToken: string): Promise<DropboxAccount> {
  const res = await fetch(ACCOUNT_URL, { method: 'POST', headers: { Authorization: `Bearer ${accessToken}` } })
  const j = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(j.error_summary || `Account lookup failed (HTTP ${res.status})`)
  return {
    name: j.name?.display_name ?? 'Dropbox user',
    email: j.email ?? '',
    accountId: j.account_id ?? '',
    accountType: j.account_type?.['.tag'] ?? 'basic',
  }
}

/** Real upload via /2/files/upload (files up to 150 MB). Folders are created implicitly. */
export async function uploadFile(accessToken: string, path: string, content: string): Promise<{ size: number }> {
  const res = await fetch(UPLOAD_URL, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/octet-stream',
      'Dropbox-API-Arg': JSON.stringify({ path, mode: 'overwrite', autorename: false, mute: true }),
    },
    body: new Blob([content]),
  })
  const j = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(j.error_summary || `Upload failed (HTTP ${res.status})`)
  return { size: j.size ?? 0 }
}

export async function revokeToken(accessToken: string): Promise<void> {
  try { await fetch(REVOKE_URL, { method: 'POST', headers: { Authorization: `Bearer ${accessToken}` } }) } catch { /* best effort */ }
}

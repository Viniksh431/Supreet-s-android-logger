import type { Category, DeviceState, EventStatus, LogEntry, Severity } from './types'

export interface SimApp { name: string; pkg: string }
export const APPS: SimApp[] = [
  { name: 'Chrome', pkg: 'com.android.chrome' },
  { name: 'WhatsApp', pkg: 'com.whatsapp' },
  { name: 'YouTube', pkg: 'com.google.android.youtube' },
  { name: 'Instagram', pkg: 'com.instagram.android' },
  { name: 'Gmail', pkg: 'com.google.android.gm' },
  { name: 'Google Maps', pkg: 'com.google.android.apps.maps' },
  { name: 'Spotify', pkg: 'com.spotify.music' },
  { name: 'Camera', pkg: 'com.android.camera2' },
  { name: 'Settings', pkg: 'com.android.settings' },
  { name: 'Play Store', pkg: 'com.android.vending' },
  { name: 'Netflix', pkg: 'com.netflix.mediaclient' },
  { name: 'Calculator', pkg: 'com.google.android.calculator' },
  { name: 'Photos', pkg: 'com.google.android.apps.photos' },
  { name: 'Dropbox', pkg: 'com.dropbox.android' },
]
// weighted popularity so that "most used app" is meaningful
const APP_WEIGHTS = [10, 14, 9, 8, 6, 4, 5, 3, 3, 2, 4, 2, 3, 2]

const SSIDS = ['Campus-WiFi', 'Home_5G', 'Cafe_Guest', 'Library-Net', 'Hostel_WiFi']
const BT_DEVICES = ['Wireless Earbuds', 'Car Audio', 'Smart Watch', 'BT Speaker', 'Fitness Band']

export type RawEvent = Omit<LogEntry, 'id'>

const rnd = (n: number) => Math.floor(Math.random() * n)
const pick = <T,>(a: T[]): T => a[rnd(a.length)]
function weighted<T>(items: T[], weights: number[]): T {
  const total = weights.reduce((a, b) => a + b, 0)
  let r = Math.random() * total
  for (let i = 0; i < items.length; i++) { r -= weights[i]; if (r <= 0) return items[i] }
  return items[items.length - 1]
}
export const pickApp = () => weighted(APPS, APP_WEIGHTS)

export function initialDevice(now = Date.now()): DeviceState {
  return {
    screenOn: false, locked: true, wifi: true, ssid: pick(SSIDS), bluetooth: false,
    battery: 55 + rnd(40), charging: false, network: 'WIFI', foreground: null, uptimeStart: now,
  }
}

function ev(ts: number, category: Category, source: string, description: string,
  severity: Severity = 'INFO', status: EventStatus = 'Success'): RawEvent {
  return { ts, category, source, description, severity, status }
}

/** Produces the next plausible event(s) and mutates `s` (the simulated device state). */
export function nextEvents(s: DeviceState, ts: number): RawEvent[] {
  const out: RawEvent[] = []
  const roll = Math.random()

  // ---- background / system-level events (independent of screen) ----
  if (roll < 0.10) {
    // battery change
    const delta = s.charging ? 1 : -1
    s.battery = Math.min(100, Math.max(1, s.battery + delta * (1 + rnd(2))))
    const sev: Severity = s.battery <= 5 ? 'CRITICAL' : s.battery <= 10 ? 'ERROR' : s.battery <= 20 ? 'WARN' : 'INFO'
    out.push(ev(ts, 'Battery', 'BatteryManager', `Battery level changed to ${s.battery}%${s.charging ? ' (charging)' : ''}${sev === 'WARN' ? ' - low battery' : ''}`, sev))
    if (s.battery === 100 && s.charging) {
      s.charging = false
      out.push(ev(ts, 'Power', 'BatteryManager', 'Charging stopped (battery full)'))
    }
    if (s.battery <= 15 && !s.charging && Math.random() < 0.6) {
      s.charging = true
      out.push(ev(ts, 'Power', 'BatteryManager', 'Charging started (USB charger connected)'))
    }
    return out
  }
  if (roll < 0.15) {
    if (s.charging) { s.charging = false; out.push(ev(ts, 'Power', 'BatteryManager', 'Charging stopped (charger disconnected)')) }
    else { s.charging = true; out.push(ev(ts, 'Power', 'BatteryManager', `Charging started (${Math.random() < 0.5 ? 'AC adapter' : 'USB charger'} connected)`)) }
    return out
  }
  if (roll < 0.22) {
    if (s.wifi) {
      s.wifi = false; s.ssid = null
      out.push(ev(ts, 'Wi-Fi', 'WifiManager', 'Wi-Fi disconnected (signal lost)', 'WARN'))
      s.network = Math.random() < 0.7 ? 'MOBILE' : 'NONE'
      out.push(ev(ts, 'Network', 'ConnectivityManager', s.network === 'MOBILE' ? 'Network connectivity changed: WIFI → MOBILE (LTE)' : 'Network connectivity changed: WIFI → NONE', s.network === 'NONE' ? 'WARN' : 'INFO'))
    } else if (Math.random() < 0.1) {
      out.push(ev(ts, 'Wi-Fi', 'WifiManager', `Wi-Fi connection to '${pick(SSIDS)}' failed (authentication timeout)`, 'ERROR', 'Failed'))
    } else {
      s.wifi = true; s.ssid = pick(SSIDS)
      out.push(ev(ts, 'Wi-Fi', 'WifiManager', `Wi-Fi connected to '${s.ssid}' (RSSI -${40 + rnd(35)} dBm)`))
      s.network = 'WIFI'
      out.push(ev(ts, 'Network', 'ConnectivityManager', 'Network connectivity changed: MOBILE/NONE → WIFI'))
    }
    return out
  }
  if (roll < 0.28) {
    s.bluetooth = !s.bluetooth
    out.push(ev(ts, 'Bluetooth', 'BluetoothAdapter', s.bluetooth ? 'Bluetooth enabled' : 'Bluetooth disabled'))
    if (s.bluetooth && Math.random() < 0.6) out.push(ev(ts + 1, 'Bluetooth', 'BluetoothAdapter', `Paired device connected: ${pick(BT_DEVICES)}`))
    return out
  }
  if (roll < 0.295) {
    out.push(ev(ts, 'Network', 'ConnectivityManager', `Network latency probe: ${20 + rnd(180)} ms`, 'DEBUG'))
    return out
  }
  if (roll < 0.30) {
    // device restart
    out.push(ev(ts, 'System', 'PowerManager', 'Device restarted (reboot requested)', 'WARN'))
    out.push(ev(ts + 1, 'System', 'SystemServer', 'Boot completed, system services started'))
    s.screenOn = false; s.locked = true; s.foreground = null; s.uptimeStart = ts
    return out
  }

  // ---- user-interaction events driven by device state ----
  if (!s.screenOn) {
    s.screenOn = true
    out.push(ev(ts, 'Screen', 'DisplayManager', 'Screen turned ON'))
    return out
  }
  if (s.locked) {
    if (Math.random() < 0.8) {
      s.locked = false
      out.push(ev(ts, 'Security', 'KeyguardManager', `Device unlocked (${pick(['fingerprint', 'PIN', 'face unlock', 'pattern'])})`))
    } else {
      s.screenOn = false
      out.push(ev(ts, 'Screen', 'DisplayManager', 'Screen turned OFF (timeout)'))
    }
    return out
  }
  // unlocked + screen on
  if (!s.foreground) {
    const app = pickApp()
    s.foreground = app.pkg
    out.push(ev(ts, 'Application', app.pkg, `Application opened: ${app.name}`))
    return out
  }
  const cur = APPS.find(a => a.pkg === s.foreground)!
  const r2 = Math.random()
  if (r2 < 0.55) {
    // close current app, maybe open another
    const crash = Math.random() < 0.05
    out.push(crash
      ? ev(ts, 'Application', cur.pkg, `Application closed: ${cur.name} (not responding - ANR)`, 'ERROR', 'Failed')
      : ev(ts, 'Application', cur.pkg, `Application closed: ${cur.name}`))
    s.foreground = null
    if (Math.random() < 0.5) {
      const next = pickApp()
      s.foreground = next.pkg
      out.push(ev(ts + 1, 'Application', next.pkg, `Application opened: ${next.name}`))
    }
  } else if (r2 < 0.8) {
    // user locks the device
    out.push(ev(ts, 'Application', cur.pkg, `Application closed: ${cur.name}`))
    s.foreground = null
    s.screenOn = false; s.locked = true
    out.push(ev(ts + 1, 'Screen', 'DisplayManager', 'Screen turned OFF'))
    out.push(ev(ts + 2, 'Security', 'KeyguardManager', 'Device locked'))
  } else {
    out.push(ev(ts, 'Application', cur.pkg, `${cur.name} memory usage sampled: ${60 + rnd(380)} MB`, 'DEBUG'))
  }
  return out
}

/** Builds a history of `days` days of backdated events with a realistic day/night rhythm. */
export function generateHistory(days: number, now = Date.now()): RawEvent[] {
  const out: RawEvent[] = []
  const state = initialDevice(now - days * 86400_000)
  const start = now - days * 86400_000
  let t = start
  while (t < now) {
    const hour = new Date(t).getHours()
    // activity intensity by hour (sleep at night, peaks morning/evening)
    const intensity = hour < 6 ? 0.08 : hour < 9 ? 0.6 : hour < 12 ? 0.8 : hour < 14 ? 0.7 : hour < 18 ? 0.75 : hour < 23 ? 1 : 0.35
    const gap = (60_000 + Math.random() * 240_000) / intensity
    t += gap
    if (t >= now) break
    out.push(...nextEvents(state, Math.floor(t)))
  }
  return out
}

/** A batch of events for the "Generate Sample Activity" button (spread over the last few minutes). */
export function generateBurst(state: DeviceState, count: number, now = Date.now()): RawEvent[] {
  const out: RawEvent[] = []
  let t = now - count * 4000
  while (out.length < count) {
    t += 1500 + rnd(3000)
    out.push(...nextEvents(state, Math.min(t, now)))
  }
  return out.slice(0, count)
}

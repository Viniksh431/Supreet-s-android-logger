import type { LogEntry } from './types'

const p2 = (n: number) => String(n).padStart(2, '0')
export function fmtDateTime(ts: number): string {
  const d = new Date(ts)
  return `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())} ${p2(d.getHours())}:${p2(d.getMinutes())}:${p2(d.getSeconds())}`
}
export function fmtTime(ts: number): string {
  const d = new Date(ts)
  return `${p2(d.getHours())}:${p2(d.getMinutes())}:${p2(d.getSeconds())}`
}
export function dayKey(ts: number): string {
  const d = new Date(ts)
  return `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`
}
export function fmtBytes(n: number): string {
  if (n < 1024) return `${n} B`
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`
  return `${(n / 1024 / 1024).toFixed(2)} MB`
}
export function relTime(ts: number | null, now = Date.now()): string {
  if (!ts) return 'Never'
  const s = Math.max(0, Math.round((now - ts) / 1000))
  if (s < 5) return 'just now'
  if (s < 60) return `${s}s ago`
  if (s < 3600) return `${Math.floor(s / 60)}m ago`
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`
  return `${Math.floor(s / 86400)}d ago`
}
export function fmtDuration(ms: number): string {
  const s = Math.max(0, Math.floor(ms / 1000))
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60
  return h ? `${h}h ${m}m ${sec}s` : m ? `${m}m ${sec}s` : `${sec}s`
}

export function txtLine(l: LogEntry): string {
  return `[${fmtDateTime(l.ts)}] ${l.id} | ${l.severity.padEnd(8)} | ${l.category.padEnd(11)} | ${l.source} | ${l.description} | ${l.status}`
}
export function formatTxt(logs: LogEntry[]): string {
  const header = `# Android Logger activity log\n# Generated: ${fmtDateTime(Date.now())}\n# Entries: ${logs.length}\n# NOTE: simulated, non-sensitive system events only\n`
  return header + logs.map(txtLine).join('\n') + '\n'
}
const q = (s: string) => `"${s.replace(/"/g, '""')}"`
export function formatCsv(logs: LogEntry[]): string {
  const head = 'log_id,timestamp,epoch_ms,category,source,description,status,severity'
  return head + '\n' + logs.map(l =>
    [l.id, fmtDateTime(l.ts), l.ts, l.category, q(l.source), q(l.description), l.status, l.severity].join(',')
  ).join('\n') + '\n'
}
export function downloadFile(name: string, content: string, mime: string) {
  const blob = new Blob([content], { type: mime + ';charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = name
  document.body.appendChild(a); a.click(); a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}
export const byteLen = (s: string) => new TextEncoder().encode(s).length

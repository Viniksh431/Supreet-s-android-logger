import type { LogEntry, SyncRecord, Category, Severity } from './types'
import { CATEGORIES, SEVERITIES } from './types'
import { dayKey, txtLine } from './format'

export interface Analytics {
  total: number
  today: number
  firstTs: number | null
  lastTs: number | null
  spanMinutes: number
  avgPerMinute: number
  lastHourPerMinute: number
  logBytes: number
  hourOfDay: { hour: string; count: number }[]
  last24h: { label: string; count: number }[]
  perDay: { day: string; label: string; count: number }[]
  perMinute: { label: string; count: number }[]
  appUsage: { name: string; count: number }[]
  topApp: { name: string; count: number } | null
  categories: { name: Category; count: number }[]
  severities: { name: Severity; count: number }[]
  storageByDay: { label: string; kb: number }[]
  uniqueApps: number
  avgPerHour: number
  avgPerDay: number
  sync: {
    total: number; success: number; failed: number; partial: number
    bytes: number; files: number
    live: { total: number; bytes: number; files: number; success: number; failed: number }
    demo: { total: number; bytes: number; files: number; success: number; failed: number }
    lastTs: number | null
  }
}

const OPEN_RE = /^Application opened: (.+)$/

export function computeAnalytics(logs: LogEntry[], syncs: SyncRecord[], now = Date.now()): Analytics {
  const total = logs.length
  const todayKey = dayKey(now)
  let today = 0, logBytes = 0
  let first: number | null = null, last: number | null = null
  const hours = new Array(24).fill(0)
  const catMap = new Map<Category, number>()
  const sevMap = new Map<Severity, number>()
  const appMap = new Map<string, number>()
  const dayCount = new Map<string, number>()
  const dayBytes = new Map<string, number>()
  const hourBuckets = new Map<number, number>()  // hours-ago -> count
  const minBuckets = new Map<number, number>()   // minutes-ago -> count
  let lastHour = 0

  for (const l of logs) {
    if (first === null || l.ts < first) first = l.ts
    if (last === null || l.ts > last) last = l.ts
    const dk = dayKey(l.ts)
    if (dk === todayKey) today++
    const bytes = txtLine(l).length + 1
    logBytes += bytes
    dayCount.set(dk, (dayCount.get(dk) ?? 0) + 1)
    dayBytes.set(dk, (dayBytes.get(dk) ?? 0) + bytes)
    hours[new Date(l.ts).getHours()]++
    catMap.set(l.category, (catMap.get(l.category) ?? 0) + 1)
    sevMap.set(l.severity, (sevMap.get(l.severity) ?? 0) + 1)
    if (l.category === 'Application') {
      const m = OPEN_RE.exec(l.description)
      if (m) appMap.set(m[1], (appMap.get(m[1]) ?? 0) + 1)
    }
    const age = now - l.ts
    if (age >= 0 && age < 24 * 3600_000) {
      const h = Math.floor(age / 3600_000)
      hourBuckets.set(h, (hourBuckets.get(h) ?? 0) + 1)
    }
    if (age >= 0 && age < 30 * 60_000) {
      const m = Math.floor(age / 60_000)
      minBuckets.set(m, (minBuckets.get(m) ?? 0) + 1)
    }
    if (age >= 0 && age < 3600_000) lastHour++
  }

  const spanMinutes = first !== null && last !== null ? Math.max(1, (Math.max(last, now) - first) / 60_000) : 0
  const spanHours = Math.max(1, spanMinutes / 60)
  const spanDays = Math.max(1, spanMinutes / 1440)

  const last24h = Array.from({ length: 24 }, (_, i) => {
    const hAgo = 23 - i
    const d = new Date(now - hAgo * 3600_000)
    return { label: `${String(d.getHours()).padStart(2, '0')}:00`, count: hourBuckets.get(hAgo) ?? 0 }
  })
  const perMinute = Array.from({ length: 30 }, (_, i) => {
    const mAgo = 29 - i
    const d = new Date(now - mAgo * 60_000)
    return { label: `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`, count: minBuckets.get(mAgo) ?? 0 }
  })
  const perDay = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(now - (6 - i) * 86400_000)
    const k = dayKey(d.getTime())
    return { day: k, label: d.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric' }), count: dayCount.get(k) ?? 0 }
  })
  // storage consumption: cumulative KB at the end of each of the last 7 days
  let cumBefore = 0
  const win = new Set(perDay.map(p => p.day))
  for (const [k, b] of dayBytes) if (!win.has(k) && k < perDay[0].day) cumBefore += b
  let run = cumBefore
  const storageByDay = perDay.map(p => { run += dayBytes.get(p.day) ?? 0; return { label: p.label, kb: +(run / 1024).toFixed(1) } })

  const appUsage = [...appMap].map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count)
  const sync = {
    total: syncs.length, success: 0, failed: 0, partial: 0, bytes: 0, files: 0, lastTs: null as number | null,
    live: { total: 0, bytes: 0, files: 0, success: 0, failed: 0 },
    demo: { total: 0, bytes: 0, files: 0, success: 0, failed: 0 },
  }
  for (const s of syncs) {
    const okFiles = s.files.filter(f => f.ok).length
    if (s.status === 'success') sync.success++
    else if (s.status === 'failed') sync.failed++
    else sync.partial++
    sync.bytes += s.bytes; sync.files += okFiles
    if (s.status !== 'failed' && (sync.lastTs === null || s.ts > sync.lastTs)) sync.lastTs = s.ts
    const m = sync[s.mode]
    m.total++; m.bytes += s.bytes; m.files += okFiles
    if (s.status === 'success') m.success++; else if (s.status === 'failed') m.failed++
  }

  return {
    total, today, firstTs: first, lastTs: last, spanMinutes,
    avgPerMinute: spanMinutes ? total / spanMinutes : 0,
    lastHourPerMinute: lastHour / 60,
    logBytes,
    hourOfDay: hours.map((count, h) => ({ hour: `${String(h).padStart(2, '0')}`, count })),
    last24h, perDay, perMinute, appUsage,
    topApp: appUsage[0] ?? null,
    categories: CATEGORIES.map(name => ({ name, count: catMap.get(name) ?? 0 })).filter(c => c.count > 0).sort((a, b) => b.count - a.count),
    severities: SEVERITIES.map(name => ({ name, count: sevMap.get(name) ?? 0 })),
    storageByDay,
    uniqueApps: appMap.size,
    avgPerHour: total / spanHours,
    avgPerDay: total / spanDays,
    sync,
  }
}
